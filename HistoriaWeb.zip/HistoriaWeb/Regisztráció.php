<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/formázások.css">
    <title>Regisztráció</title>
</head>
<body>
</body>
</html>
<?php
    $adatbazis="adatok";
    $hostname="localhost";
    $adatbazis_felhasznalonev="root";
    $adatbazis_jelszo="";
    $kapcsolat= mysqli_connect($hostname,$adatbazis_felhasznalonev,$adatbazis_jelszo,$adatbazis);
    if(!$kapcsolat)
    {
        die("Sikertelen kapcsolódás: ".mysqli_connect_error());
    }
    $email=$_POST["email"];
    $felhasznalonev=$_POST["felhasználónév"];
    $jelszo=$_POST["jelszó"];
    $ellenorzes="SELECT * FROM fiókok WHERE felhasználónevek='$felhasznalonev'";
    $eredmeny=$kapcsolat->query($ellenorzes);
    $van_e=$eredmeny->num_rows;
    if($van_e>0)
    {
        echo
        "
        <div class='d-flex justify-content-center align-items-center r_b_valasz'>
            <h1>Ez a felhasználónév már létezik!</h1>
        </div>
        <div class='d-flex justify-content-center align-items-center'>
            <button class='btn btn-primary me-5 mt-5'>
                <a href='Regisztráció.html'>Vissza</a>
            </button>
            <button class='btn btn-primary mt-5'>
                <a href='Bejelentkezés.html'>Bejelentkezés</a>
            </button>
        </div>
        ";  
    }
    else
    {
        echo
        "
        <div class='d-flex justify-content-center align-items-center r_b_valasz'>
            <h1>Sikeres regisztráció!</h1>
        </div>
        <div class='d-flex justify-content-center align-items-center'>
            <button class='btn btn-primary me-5 mt-5'>
                <a href='Regisztráció.html'>Vissza</a>
            </button>
            <button class='btn btn-primary mt-5'>
                <a href='Bejelentkezés.html'>Tovább</a>
            </button>
        </div>
        ";
        $bekuldes="INSERT INTO fiókok(felhasználónevek,jelszavak,email) VALUES('$felhasznalonev','$jelszo','$email')";
        $kapcsolat->query($bekuldes);
    }
?>