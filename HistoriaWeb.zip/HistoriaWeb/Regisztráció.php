<?php
    $adatbazis="adatok";
    $hostname="localhost";
    $adatbazis_felhasznalonev="root";
    $adatbazis_jelszo="";
    $kapcsolat= mysqli_connect($hostname,$adatbazis_felhasznalonev,$adatbazis_jelszo,$adatbazis);
    if(!$kapcsolat)
    {
        die("Sikertelen kapcsolódás: ".mysqli_connect_error());
    }
    $email=$_POST["email"];
    $felhasznalonev=$_POST["felhasználónév"];
    $jelszo=$_POST["jelszó"];
    $bekuldes="INSERT INTO fiókok(felhasználónevek,jelszavak,email) VALUES('$felhasznalonev','$jelszo','$email')";
    $kapcsolat->query($bekuldes);
?>