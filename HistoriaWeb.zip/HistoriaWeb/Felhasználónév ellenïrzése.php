<?php
    $adatbazis="adatok";
    $hostname="localhost";
    $adatbazis_felhasznalonev="root";
    $adatbazis_jelszo="";
    $kapcsolat= mysqli_connect($hostname,$adatbazis_felhasznalonev,$adatbazis_jelszo,$adatbazis);
    if(!$kapcsolat)
    {
        die("Sikertelen kapcsolódás: ".mysqli_connect_error());
    }
    $felhasznalonev=$_GET["felhasználónév"];
    $ellenorzes="SELECT * FROM fiókok WHERE felhasználónevek='$felhasznalonev'";
    $eredmeny=$kapcsolat->query($ellenorzes);
    $van_e=$eredmeny->num_rows;
    echo $van_e;
?>