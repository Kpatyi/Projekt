window.addEventListener('scroll',()=>{
    let ertek=window.scrollY;
    document.getElementById("cim").style.marginTop=ertek*2.25+'px';
    document.getElementById("jf").style.marginTop=ertek*-1.5+'px';
    document.getElementById("jf").style.marginLeft=ertek*1.5+'px';
    document.getElementById("bf").style.marginTop=ertek*-1.5+'px';
    document.getElementById("bf").style.marginLeft=ertek*-1.5+'px';
    document.getElementById("ba").style.marginTop=ertek*0.5+'px';
    document.getElementById("ba").style.marginLeft=ertek*-1.5+'px';
    document.getElementById("ja").style.marginTop=ertek*0.5+'px';
    document.getElementById("ja").style.marginLeft=ertek*1.5+'px';
});
function felhasznalonev_van_r()
{
    const osszes=document.getElementsByClassName("form-control");
    let felhasznalonev=osszes[1];
    const ajax=new XMLHttpRequest();
    ajax.onload=function()
    {
        let van=parseInt(this.responseText);
        if(felhasznalonev.value=="")
        {
            felhasznalonev.style="border: 2px solid red;";
        }
        else
        {
            if(van>0)
            {
                felhasznalonev.style="border: 2px solid red;";
                document.getElementById("felhasznalonev_van").style="display:block;";
            }
            else
            {
                felhasznalonev.style="border: 2px solid green;";
                document.getElementById("felhasznalonev_van").style="display:none;";
            }
        }
    }
    ajax.open("GET","Felhasználónév ellenőrzése.php?felhasználónév="+felhasznalonev.value);
    ajax.send();
}
function kitoltote_b()
{
    const osszes=document.getElementsByClassName("form-control");
    let felhasznalonev=osszes[0];
    let jelszo=osszes[1];
    if(felhasznalonev.value=="")
    {
        felhasznalonev.style="border: 2px solid red;";
    }
    else
    {
        felhasznalonev.style="border: 2px solid green;";
    }
    if(jelszo.value=="")
    {
        jelszo.style="border: 2px solid red;";
    }
    else
    {
        jelszo.style="border: 2px solid green;";
    }
    const ajax=new XMLHttpRequest();
    ajax.onload=function()
    {
        let van=parseInt(this.responseText);
        if(van>0)
        {
            felhasznalonev.style="border: 2px solid green;";
            jelszo.style="border: 2px solid green;";
            document.getElementById("felhasznalonev_van").style="display:none;";
        }
        else
        {
            felhasznalonev.style="border: 2px solid red;";
            jelszo.style="border: 2px solid red;";
            document.getElementById("felhasznalonev_van").style="display:block;";
        }
    }
    ajax.open("GET","Fiók ellenőrzése.php?felhasználónév="+felhasznalonev.value+"&jelszó="+jelszo.value);
    ajax.send();
}
function kitoltote_r()
{
    const osszes=document.getElementsByClassName("form-control");
    let email=osszes[0];
    let jelszo=osszes[2];
    let jelszo_i=osszes[3];
    if(email.value=="")
    {
        email.style="border: 2px solid red;";
    }
    else
    {
        email.style="border: 2px solid green;";
    }
    if(jelszo.value=="")
    {
        jelszo.style="border: 2px solid red;";
    }
    else
    {
        jelszo.style="border: 2px solid green;";
    }
    if(jelszo_i.value=="")
    {
        jelszo_i.style="border: 2px solid red;";
    }
    else
    {
        jelszo_i.style="border: 2px solid green;";
    }
}
function jelszo_ellenorzes()
{
    if(jelszo.value!=jelszo_i.value)
    {
        jelszo_i.style="border:2px solid red;";
        document.getElementById("jelszo_nem_e").style="display:block;";
    }
    else
    {
        jelszo_i.style="border:2px solid green;";
        document.getElementById("jelszo_nem_e").style="display:none;";
    }
}
function Kuldes_r()
{
    const osszes=document.getElementsByClassName("form-control");
    let email=osszes[0];
    let fehasznalonev=osszes[1];
    let jelszo=osszes[2];
    if(document.getElementById("jelszo_nem_e").style.display=="block" || document.getElementById("felhasznalonev_van").style.display=="block" || email.value=="" || jelszo_i.value=="")
    {
        return false;
    }
    else
    {
        const ajax=new XMLHttpRequest();
        ajax.open("POST","Regisztráció.php");
        ajax.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
        ajax.onload=function()
        {
            return true;
        }
        ajax.send("email="+email.value+"&felhasználónév="+fehasznalonev.value+"&jelszó="+jelszo.value);
    }
}
function Kuldes_b()
{
    const osszes=document.getElementsByClassName("form-control");
    let fehasznalonev=osszes[0];
    let jelszo=osszes[1];
    if( fehasznalonev.value=="" || jelszo.value=="" || document.getElementById("felhasznalonev_van").style.display=="block")
    {
        return false;
    }
    else
    {
        return true;
    }
}
function mutasd_j()
{
    let jelszo=document.getElementById("jelszo")
    if(jelszo.type==="password")
    {
        jelszo.type="text";
    }
    else{
        jelszo.type="password";
    }
}
function mutasd_j_i()
{
    let jelszo=document.getElementById("jelszo_i")
    if(jelszo.type=="password")
    {
        jelszo.type="text";
    }
    else{
        jelszo.type="password";
    }
}
function helyek()
{
    const ajax=new XMLHttpRequest();
    ajax.onload=function()
    {
        const egesz=this.responseText;
        document.getElementById("helyek").innerHTML=egesz;
    }
    ajax.open("GET","Helyek.php");
    ajax.send()
}