function helyek()
{
    const ajax=new XMLHttpRequest();
    ajax.onload=function()
    {
        const egesz=this.responseText;
        document.getElementById("helyek").innerHTML=egesz;
    }
    ajax.open("GET","Helyek.php");
    ajax.send()
}
window.addEventListener('scroll',()=>{
    let ertek=window.scrollY;
    document.getElementById("cim").style.marginTop=ertek*2.25+'px';
    document.getElementById("jf").style.marginTop=ertek*-1.5+'px';
    document.getElementById("jf").style.marginLeft=ertek*1.5+'px';
    document.getElementById("bf").style.marginTop=ertek*-1.5+'px';
    document.getElementById("bf").style.marginLeft=ertek*-1.5+'px';
    document.getElementById("ba").style.marginTop=ertek*0.5+'px';
    document.getElementById("ba").style.marginLeft=ertek*-1.5+'px';
    document.getElementById("ja").style.marginTop=ertek*0.5+'px';
    document.getElementById("ja").style.marginLeft=ertek*1.5+'px';
});
function validateForm(){
    let jelszo=document.getElementById("jelszo").value;
    let jelszo_i=document.getElementById("jelszo_i").value;
    if(jelszo!=jelszo_i)
    {
        alert("A jelszavak nem egyeznek!")
        return false;
    }
    else
    {
        return true;
    }
}
function mutasd_j()
{
    let jelszo=document.getElementById("jelszo")
    if(jelszo.type==="password")
    {
        jelszo.type="text";
    }
    else{
        jelszo.type="password";
    }
}
function mutasd_j_i()
{
    let jelszo=document.getElementById("jelszo_i")
    if(jelszo.type==="password")
    {
        jelszo.type="text";
    }
    else{
        jelszo.type="password";
    }
}