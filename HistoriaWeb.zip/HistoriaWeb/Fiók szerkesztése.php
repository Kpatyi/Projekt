<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/formázások.css">
    <script src="bootstrap/js/bootstrap.min.js"></script>
    <script src="js/funkciók.js"></script>
    <title>Fiók szerkesztése</title>
</head>
<body>
</body>
<?php
session_start();
$felhasznalonev=$_SESSION["felhasználónév"];
$jelszo=$_SESSION["jelszó"];

    $adatbazis="adatok";
    $hostname="localhost";
    $adatbazis_felhasznalonev="root";
    $adatbazis_jelszo="";
    $kapcsolat= mysqli_connect($hostname,$adatbazis_felhasznalonev,$adatbazis_jelszo,$adatbazis);
    if(!$kapcsolat)
    {
        die("Sikertelen kapcsolódás: ".mysqli_connect_error());
    }
    $ellenorzes="SELECT * FROM fiókok WHERE felhasználónevek='$felhasznalonev' and jelszavak='$jelszo'";
    $eredmeny=$kapcsolat->query($ellenorzes);
    while($sor=$eredmeny->fetch_assoc())
    {
        echo 
        "
        <h1 id='b_r'>Fiók szerkeztése</h1>   
        <table style='border:2px solid black;margin-left:35%'>
            <tr>
                <td>Felhasználónév:</td>
                <td>" . $sor["felhasználónevek"]. "</td>
            </tr>
            <tr>
                <td>Jelszó:</td>
                <td>" . $sor["jelszavak"]. "</td>
            </tr>
        </table>
        ";
    }
?>