<?php
    $megye=$_GET["megye"];
    echo $megye
?>