window.addEventListener('scroll',()=>{
    let ertek=window.scrollY;
    document.getElementById("cim").style.marginTop=ertek*2.25+'px';
    document.getElementById("jf").style.marginTop=ertek*-1.5+'px';
    document.getElementById("jf").style.marginLeft=ertek*1.5+'px';
    document.getElementById("bf").style.marginTop=ertek*-1.5+'px';
    document.getElementById("bf").style.marginLeft=ertek*-1.5+'px';
    document.getElementById("ba").style.marginTop=ertek*0.5+'px';
    document.getElementById("ba").style.marginLeft=ertek*-1.5+'px';
    document.getElementById("ja").style.marginTop=ertek*0.5+'px';
    document.getElementById("ja").style.marginLeft=ertek*1.5+'px';
});