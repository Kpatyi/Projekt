﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projekt
{
    public partial class Batyu : Form
    {
        public Batyu()
        {
            InitializeComponent();
        }

        private void Batyu_Load(object sender, EventArgs e)
        {

        }

        private void Belépés_Click(object sender, EventArgs e)
        {
            Belépés.Visible = false;
            Regisztráció.Visible = false;
            Felhasználónév.Visible = true;
            F_szöveg.Visible=true;
            Jelszó.Visible = true;
            J_szöveg.Visible = true;
            B_szöveg.Visible = true;
            Mutasd.Visible = true;
            Belépés2.Visible = true;
            Mégse.Visible = true;


        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Jszöveg_TextChanged(object sender, EventArgs e)
        {

        }

        private void Mutasd_CheckedChanged(object sender, EventArgs e)
        {
            if (Mutasd.Checked == true)
            {
                J_szöveg.UseSystemPasswordChar = false;
            }
            else
            {
                J_szöveg.UseSystemPasswordChar = true;
            }
        }

        private void Belépés2_Click(object sender, EventArgs e)
        {
            F_szöveg.Clear();
            J_szöveg.Clear();
        }

        private void Mégse_Click(object sender, EventArgs e)
        {
            Belépés.Visible = true;
            Regisztráció.Visible = true;
            Felhasználónév.Visible =false;
            F_szöveg.Visible = false;
            Jelszó.Visible = false;
            J_szöveg.Visible = false;
            B_szöveg.Visible = false;
            Mutasd.Visible = false;
            Belépés2.Visible = false;
            Mégse.Visible = false;
            F_szöveg.Clear();
            J_szöveg.Clear();
        }
    }
}
