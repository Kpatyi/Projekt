﻿
namespace Projekt
{
    partial class Batyu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.Belépés = new System.Windows.Forms.Button();
            this.Regisztráció = new System.Windows.Forms.Button();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.ssssToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.B_szöveg = new System.Windows.Forms.Label();
            this.F_szöveg = new System.Windows.Forms.TextBox();
            this.Felhasználónév = new System.Windows.Forms.Label();
            this.Jelszó = new System.Windows.Forms.Label();
            this.J_szöveg = new System.Windows.Forms.TextBox();
            this.Mutasd = new System.Windows.Forms.CheckBox();
            this.Belépés2 = new System.Windows.Forms.Button();
            this.Mégse = new System.Windows.Forms.Button();
            this.contextMenuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // Belépés
            // 
            this.Belépés.BackColor = System.Drawing.Color.Transparent;
            this.Belépés.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Belépés.Font = new System.Drawing.Font("Times New Roman", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Belépés.ForeColor = System.Drawing.Color.Blue;
            this.Belépés.Location = new System.Drawing.Point(521, 12);
            this.Belépés.Name = "Belépés";
            this.Belépés.Size = new System.Drawing.Size(157, 43);
            this.Belépés.TabIndex = 0;
            this.Belépés.Text = "Belépés";
            this.Belépés.UseVisualStyleBackColor = false;
            this.Belépés.Click += new System.EventHandler(this.Belépés_Click);
            // 
            // Regisztráció
            // 
            this.Regisztráció.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Regisztráció.Font = new System.Drawing.Font("Times New Roman", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Regisztráció.ForeColor = System.Drawing.Color.Blue;
            this.Regisztráció.Location = new System.Drawing.Point(684, 12);
            this.Regisztráció.Name = "Regisztráció";
            this.Regisztráció.Size = new System.Drawing.Size(157, 43);
            this.Regisztráció.TabIndex = 1;
            this.Regisztráció.Text = "Regisztráció";
            this.Regisztráció.UseVisualStyleBackColor = true;
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ssssToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(95, 26);
            // 
            // ssssToolStripMenuItem
            // 
            this.ssssToolStripMenuItem.Name = "ssssToolStripMenuItem";
            this.ssssToolStripMenuItem.Size = new System.Drawing.Size(94, 22);
            this.ssssToolStripMenuItem.Text = "ssss";
            // 
            // B_szöveg
            // 
            this.B_szöveg.AutoSize = true;
            this.B_szöveg.Font = new System.Drawing.Font("Arial", 24.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.B_szöveg.Location = new System.Drawing.Point(357, 9);
            this.B_szöveg.Name = "B_szöveg";
            this.B_szöveg.Size = new System.Drawing.Size(132, 38);
            this.B_szöveg.TabIndex = 3;
            this.B_szöveg.Text = "Belépés";
            this.B_szöveg.Visible = false;
            this.B_szöveg.Click += new System.EventHandler(this.label1_Click);
            // 
            // F_szöveg
            // 
            this.F_szöveg.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.F_szöveg.Location = new System.Drawing.Point(364, 136);
            this.F_szöveg.Name = "F_szöveg";
            this.F_szöveg.Size = new System.Drawing.Size(125, 30);
            this.F_szöveg.TabIndex = 4;
            this.F_szöveg.Visible = false;
            this.F_szöveg.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // Felhasználónév
            // 
            this.Felhasználónév.AutoSize = true;
            this.Felhasználónév.Font = new System.Drawing.Font("Times New Roman", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Felhasználónév.Location = new System.Drawing.Point(160, 136);
            this.Felhasználónév.Name = "Felhasználónév";
            this.Felhasználónév.Size = new System.Drawing.Size(183, 31);
            this.Felhasználónév.TabIndex = 5;
            this.Felhasználónév.Text = "Felhasználónév";
            this.Felhasználónév.Visible = false;
            // 
            // Jelszó
            // 
            this.Jelszó.AutoSize = true;
            this.Jelszó.Font = new System.Drawing.Font("Times New Roman", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Jelszó.Location = new System.Drawing.Point(160, 196);
            this.Jelszó.Name = "Jelszó";
            this.Jelszó.Size = new System.Drawing.Size(80, 31);
            this.Jelszó.TabIndex = 7;
            this.Jelszó.Text = "Jelszó";
            this.Jelszó.Visible = false;
            // 
            // J_szöveg
            // 
            this.J_szöveg.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.J_szöveg.Location = new System.Drawing.Point(364, 197);
            this.J_szöveg.Name = "J_szöveg";
            this.J_szöveg.Size = new System.Drawing.Size(125, 30);
            this.J_szöveg.TabIndex = 6;
            this.J_szöveg.UseSystemPasswordChar = true;
            this.J_szöveg.Visible = false;
            this.J_szöveg.TextChanged += new System.EventHandler(this.Jszöveg_TextChanged);
            // 
            // Mutasd
            // 
            this.Mutasd.AutoSize = true;
            this.Mutasd.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Mutasd.Location = new System.Drawing.Point(364, 247);
            this.Mutasd.Name = "Mutasd";
            this.Mutasd.Size = new System.Drawing.Size(74, 21);
            this.Mutasd.TabIndex = 8;
            this.Mutasd.Text = "Mutasd";
            this.Mutasd.UseVisualStyleBackColor = true;
            this.Mutasd.Visible = false;
            this.Mutasd.CheckedChanged += new System.EventHandler(this.Mutasd_CheckedChanged);
            // 
            // Belépés2
            // 
            this.Belépés2.BackColor = System.Drawing.Color.Transparent;
            this.Belépés2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Belépés2.Font = new System.Drawing.Font("Times New Roman", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Belépés2.ForeColor = System.Drawing.Color.Black;
            this.Belépés2.Location = new System.Drawing.Point(248, 309);
            this.Belépés2.Name = "Belépés2";
            this.Belépés2.Size = new System.Drawing.Size(125, 43);
            this.Belépés2.TabIndex = 9;
            this.Belépés2.Text = "Belépés";
            this.Belépés2.UseVisualStyleBackColor = false;
            this.Belépés2.Visible = false;
            this.Belépés2.Click += new System.EventHandler(this.Belépés2_Click);
            // 
            // Mégse
            // 
            this.Mégse.BackColor = System.Drawing.Color.Transparent;
            this.Mégse.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Mégse.Font = new System.Drawing.Font("Times New Roman", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Mégse.ForeColor = System.Drawing.Color.Black;
            this.Mégse.Location = new System.Drawing.Point(456, 309);
            this.Mégse.Name = "Mégse";
            this.Mégse.Size = new System.Drawing.Size(125, 43);
            this.Mégse.TabIndex = 10;
            this.Mégse.Text = "Mégse";
            this.Mégse.UseVisualStyleBackColor = false;
            this.Mégse.Visible = false;
            this.Mégse.Click += new System.EventHandler(this.Mégse_Click);
            // 
            // Batyu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 14F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(856, 565);
            this.Controls.Add(this.Mégse);
            this.Controls.Add(this.Belépés2);
            this.Controls.Add(this.Mutasd);
            this.Controls.Add(this.Jelszó);
            this.Controls.Add(this.J_szöveg);
            this.Controls.Add(this.Felhasználónév);
            this.Controls.Add(this.F_szöveg);
            this.Controls.Add(this.B_szöveg);
            this.Controls.Add(this.Regisztráció);
            this.Controls.Add(this.Belépés);
            this.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Name = "Batyu";
            this.Text = "Batyu";
            this.Load += new System.EventHandler(this.Batyu_Load);
            this.contextMenuStrip1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Belépés;
        private System.Windows.Forms.Button Regisztráció;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem ssssToolStripMenuItem;
        private System.Windows.Forms.Label B_szöveg;
        private System.Windows.Forms.TextBox F_szöveg;
        private System.Windows.Forms.Label Felhasználónév;
        private System.Windows.Forms.Label Jelszó;
        private System.Windows.Forms.TextBox J_szöveg;
        private System.Windows.Forms.CheckBox Mutasd;
        private System.Windows.Forms.Button Belépés2;
        private System.Windows.Forms.Button Mégse;
    }
}

