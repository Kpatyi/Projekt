﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace Batyu
{
    public partial class Batyu_ : Form
    {
        public Batyu_()
        {
            InitializeComponent();
        }

        private void Belépés_Click(object sender, EventArgs e)
        {
            Belépés_c.Visible = true;
            Belépés.Visible= false;
            Belépés_g.Visible = true;
            f_b_sz.Visible = true;
            j_b_sz.Visible = true;
            Regisztráció.Visible = false;
            Mutasd_b.Visible = true;
            Mégse_b.Visible = true;
            Felhasználónév_b.Visible = true;
            Jelszó_b.Visible = true;
        }

        private void Mutasd_b_CheckedChanged(object sender, EventArgs e)
        {
            if(Mutasd_b.Checked) 
            {
                j_b_sz.UseSystemPasswordChar = false;
            }
            else
            {
                j_b_sz.UseSystemPasswordChar= true;
            }
        }

        private void Mégse_b_Click(object sender, EventArgs e)
        {
            Belépés_c.Visible = false;
            Belépés.Visible = true;
            Belépés_g.Visible = false;
            f_b_sz.Visible = false;
            j_b_sz.Visible = false;
            Regisztráció.Visible = true;
            Mutasd_b.Visible = false;
            Mégse_b.Visible = false;
            Felhasználónév_b.Visible = false;
            Jelszó_b.Visible = false;
            Mutasd_b.Checked= false;
            f_b_sz.Clear();
            j_b_sz.Clear();
        }

        private void Regisztráció_Click(object sender, EventArgs e)
        {
            Regisztráció_c.Visible = true;
            Regisztráció.Visible = false;
            Belépés.Visible = false;
            Felhasználónév_r.Visible = true;
            Jelszó_r.Visible=true;
            Mutasd_r.Visible=true;
            f_r_sz.Visible=true;
            j_r_sz.Visible = true;
            Küldés.Visible = true;
            Mégse_r.Visible = true;
            Jelszó_megerősítés.Visible=true;
            Mutasd_r_m.Visible= true;
            j_m_sz.Visible=true;
            Email.Visible = true;
            e_sz.Visible = true;
            Vezetéknév.Visible = true;
            Keresztnév.Visible = true;
            K_sz.Visible = true;
            V_sz.Visible = true;
            adatkezelés.Visible = true;
        }

        private void Mégse_r_Click(object sender, EventArgs e)
        {
            Regisztráció_c.Visible = false;
            Regisztráció.Visible = true;
            Belépés.Visible = true;
            Felhasználónév_r.Visible = false;
            Jelszó_r.Visible = false;
            Mutasd_r.Visible = false;
            f_r_sz.Visible = false;
            j_r_sz.Visible = false;
            Küldés.Visible = false;
            Mégse_r.Visible = false;
            f_r_sz.Clear();
            j_r_sz.Clear();
            Mutasd_r.Checked=false;
            Jelszó_megerősítés.Visible = false;
            Mutasd_r_m.Visible = false;
            j_m_sz.Visible = false;
            j_m_sz.Clear();
            Mutasd_r_m.Checked=false;
            Email.Visible = false;
            e_sz.Visible = false;
            e_sz.Clear();
            Keresztnév.Visible = false;
            Vezetéknév.Visible = false;
            K_sz.Visible = false;
            V_sz.Visible = false;
            K_sz.Clear();
            V_sz.Clear();
            adatkezelés.Visible=false;
            adatkezelés.Checked=false;


        }

        private void Mutasd_r_CheckedChanged(object sender, EventArgs e)
        {
            if(Mutasd_r.Checked)
            {
                j_r_sz.UseSystemPasswordChar = false;
            }
            else
            {
                j_r_sz.UseSystemPasswordChar=true;
            }
        }

        private void Mutasd_r_m_CheckedChanged(object sender, EventArgs e)
        {
            if(Mutasd_r_m.Checked)
            {
                j_m_sz.UseSystemPasswordChar = false;
            }
            else
            {
                j_m_sz.UseSystemPasswordChar=true;
            }

        }
        string[] felhasznalonevek = { };
        string[] jelszavak = { };
        private void Küldés_Click(object sender, EventArgs e)
        {
            bool van_e_f = felhasznalonevek.Contains(f_r_sz.Text);
            bool van_e_j = jelszavak.Contains(j_r_sz.Text);
            if (f_r_sz.Text != "" && j_r_sz.Text != "" && j_m_sz.Text != "" && e_sz.Text != "" && adatkezelés.Checked)
            {
                if (j_r_sz.Text != j_m_sz.Text)
                {
                    MessageBox.Show("A jelszavak nem egyeznek");
                }
                else
                {
                    if (e_sz.Text.Contains('@')==false)
                    {
                        MessageBox.Show("Az email cím nem megfelelő formátumú");
                    }
                    else
                    {
                        if (van_e_f && van_e_j)
                        {
                            MessageBox.Show("Ez a fiók már létezik");
                        }
                        else
                        {
                            felhasznalonevek = felhasznalonevek.Append(f_r_sz.Text).ToArray();
                            jelszavak = jelszavak.Append(j_r_sz.Text).ToArray();
                            MessageBox.Show("Sikeres regisztráció!");
                            Regisztráció_c.Visible = false;
                            Regisztráció.Visible = true;
                            Belépés.Visible = true;
                            Felhasználónév_r.Visible = false;
                            Jelszó_r.Visible = false;
                            Mutasd_r.Visible = false;
                            f_r_sz.Visible = false;
                            j_r_sz.Visible = false;
                            Küldés.Visible = false;
                            Mégse_r.Visible = false;
                            f_r_sz.Clear();
                            j_r_sz.Clear();
                            Mutasd_r.Checked = false;
                            Jelszó_megerősítés.Visible = false;
                            Mutasd_r_m.Visible = false;
                            j_m_sz.Visible = false;
                            j_m_sz.Clear();
                            Mutasd_r_m.Checked = false;
                            Email.Visible = false;
                            e_sz.Visible = false;
                            e_sz.Clear();
                            Keresztnév.Visible = false;
                            Vezetéknév.Visible = false;
                            K_sz.Visible = false;
                            V_sz.Visible = false;
                            K_sz.Clear();
                            V_sz.Clear();
                            adatkezelés.Visible = false;
                            adatkezelés.Checked = false;
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show("Minden mezőt ki kell tölteni!");
            }
        }

        private void Belépés_g_Click(object sender, EventArgs e)
        {
            bool van_e_f = felhasznalonevek.Contains(f_b_sz.Text);
            bool van_e_j = jelszavak.Contains(j_b_sz.Text);
            if (van_e_f && van_e_j)
            {
                System.Diagnostics.Process.Start("https://petofifgy.hu");
            }
            else
            {
                MessageBox.Show("Ez a fiók nem létezik");
            }
        }
    }   
}
