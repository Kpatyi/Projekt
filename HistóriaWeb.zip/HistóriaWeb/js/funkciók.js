function parallex()
{
    let ertek=window.scrollY;
    document.getElementById("cim").style.marginTop=ertek*2.25+'px';
    document.getElementById("jf").style.marginTop=ertek*-1.5+'px';
    document.getElementById("jf").style.marginLeft=ertek*1.5+'px';
    document.getElementById("bf").style.marginTop=ertek*-1.5+'px';
    document.getElementById("bf").style.marginLeft=ertek*-1.5+'px';
    document.getElementById("ba").style.marginTop=ertek*0.5+'px';
    document.getElementById("ba").style.marginLeft=ertek*-1.5+'px';
    document.getElementById("ja").style.marginTop=ertek*0.5+'px';
    document.getElementById("ja").style.marginLeft=ertek*1.5+'px';
};
function vizsgalat_r()
{
    setTimeout(kuldes(),5000);
    let email=document.getElementById("email");
    let felhasznalonev=document.getElementById("felhasznalonev");
    let jelszo=document.getElementById("jelszo");
    const ajax=new XMLHttpRequest();
    ajax.onreadystatechange=function()
    {
        let van=parseInt(this.responseText);
        if(van>0)
        {
            document.getElementById("felhasznalonev_van").style.display="block";
        }
        else
        {
            document.getElementById("felhasznalonev_van").style.display="none";
        }
    }
    ajax.open("GET","Fiók ellenőrzése.php?felhasználónév="+felhasznalonev.value);
    ajax.send();
}
function kuldes()
{
    if(document.getElementById("felhasznalonev_van").style.display=="block")
    {
        return false;
    }
    else
    {
        return true;
    }
}
setTimeout(kuldes(),5000)
function mutasd_j()
{
    let jelszo=document.getElementById("jelszo")
    if(jelszo.type==="password")
    {
        jelszo.type="text";
    }
    else{
        jelszo.type="password";
    }
}

function mutasd_j_i()
{
    let jelszo=document.getElementById("jelszo_i")
    if(jelszo.type=="password")
    {
        jelszo.type="text";
    }
    else{
        jelszo.type="password";
    }
}

function helyek()
{
    const ajax=new XMLHttpRequest();
    ajax.onload=function()
    {
        const egesz=this.responseText;
        document.getElementById("helyek").innerHTML=egesz;
    }
    ajax.open("GET","Helyek.php");
    ajax.send()
}