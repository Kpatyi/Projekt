function parallex()
{
    let ertek=window.scrollY;
    document.getElementById("cim").style.marginTop=ertek*2.25+'px';
    document.getElementById("jf").style.marginTop=ertek*-1.5+'px';
    document.getElementById("jf").style.marginLeft=ertek*1.5+'px';
    document.getElementById("bf").style.marginTop=ertek*-1.5+'px';
    document.getElementById("bf").style.marginLeft=ertek*-1.5+'px';
    document.getElementById("ba").style.marginTop=ertek*0.5+'px';
    document.getElementById("ba").style.marginLeft=ertek*-1.5+'px';
    document.getElementById("ja").style.marginTop=ertek*0.5+'px';
    document.getElementById("ja").style.marginLeft=ertek*1.5+'px';
};
function parallex2()
{
    let ertek=window.scrollY;
    document.getElementById("cim2").style.marginTop=ertek*2.25+'px';
    document.getElementById("jf").style.marginTop=ertek*-1.5+'px';
    document.getElementById("jf").style.marginLeft=ertek*1.5+'px';
    document.getElementById("bf").style.marginTop=ertek*-1.5+'px';
    document.getElementById("bf").style.marginLeft=ertek*-1.5+'px';
    document.getElementById("ba").style.marginTop=ertek*0.5+'px';
    document.getElementById("ba").style.marginLeft=ertek*-1.5+'px';
    document.getElementById("ja").style.marginTop=ertek*0.5+'px';
    document.getElementById("ja").style.marginLeft=ertek*1.5+'px';
};
function vizsgalat_r()
{
    let email=document.getElementById("email");
    let felhasznalonev=document.getElementById("felhasznalonev");
    let jelszo=document.getElementById("jelszo");
    let jelszo_i=document.getElementById("jelszo_i");
    const ajax=new XMLHttpRequest();
    ajax.onload=function()
    {
        eval(this.responseText);
        if(email.classList.item(1)=="is-valid" && felhasznalonev.classList.item(1)=="is-valid" && jelszo.classList.item(1)=="is-valid" && jelszo_i.classList.item(1)=="is-valid")
        {
            document.getElementById("kuldes").submit();
        }
    }
    ajax.open("POST", "Regisztráció ellenőrzése.php");
    ajax.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    ajax.send("email="+email.value+"&felhasználónév="+felhasznalonev.value+"&jelszó="+jelszo.value+"&jelszó_i="+jelszo_i.value);
}

function vizsgalat_b()
{
    let felhasznalonev=document.getElementById("felhasznalonev");
    let jelszo=document.getElementById("jelszo");
    const ajax=new XMLHttpRequest();
    ajax.onload=function()
    {
        eval(this.responseText);
        if(felhasznalonev.classList.item(1)=="is-valid" && jelszo.classList.item(1)=="is-valid")
        {
            document.getElementById("kuldes").submit();
        }
    }
    ajax.open("POST", "Fiók ellenőrzése.php");
    ajax.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    ajax.send("felhasználónév="+felhasznalonev.value+"&jelszó="+jelszo.value);
}

function frissites()
{
    let email=document.getElementById("email");
    let felhasznalonev=document.getElementById("felhasznalonev");
    let jelszo=document.getElementById("jelszo");
    let jelszo_i=document.getElementById("jelszo_i");
    const ajax=new XMLHttpRequest();
    ajax.onload=function()
    {
        eval(this.responseText);
        if(email.classList.item(1)=="is-valid" && felhasznalonev.classList.item(1)=="is-valid" && jelszo.classList.item(1)=="is-valid" && jelszo_i.classList.item(1)=="is-valid")
        {
            document.getElementById("kuldes").submit();
        }
    }
    ajax.open("POST", "Fiók frissítés ellenőrzése.php");
    ajax.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    ajax.send("újemail="+email.value+"&újfelhasználónév="+felhasznalonev.value+"&újjelszó="+jelszo.value+"&újjelszó_i="+jelszo_i.value);
}

function torles()
{
    const ajax=new XMLHttpRequest();
    ajax.open("GET","Törlés.php");
    ajax.send();
}

function mutasd_j()
{
    let jelszo=document.getElementById("jelszo");
    let mutasd_j=document.getElementById("mutasd_j");
    if(jelszo.type==="password")
    {
        jelszo.type="text";
        mutasd_j.classList.replace("bi-eye-fill","bi-eye-slash-fill")
    }
    else{
        jelszo.type="password";
        mutasd_j.classList.replace("bi-eye-slash-fill","bi-eye-fill")
    }
}

function mutasd_j_i()
{
    let jelszo=document.getElementById("jelszo_i");
    let mutasd_j=document.getElementById("mutasd_j_i");
    if(jelszo.type=="password")
    {
        jelszo.type="text";
        mutasd_j.classList.replace("bi-eye-fill","bi-eye-slash-fill");
    }
    else{
        jelszo.type="password";
        mutasd_j.classList.replace("bi-eye-slash-fill","bi-eye-fill");
    }
}

function helyek()
{
    const ajax=new XMLHttpRequest();
    ajax.onload=function()
    {
        const egesz=this.responseText;
        document.getElementById("helyek").innerHTML=egesz;
    }
    ajax.open("GET","Helyek.php");
    ajax.send()
}

function feltolt()
{
    let megye= document.getElementById("megye");
    let telepules=document.getElementById("telepules");
    if(megye.value==0)
    {
        telepules.disabled=true;
        telepules.options.length=1;
    }

    if(megye.value=="Bács-Kiskun")
    {
        telepules.disabled=false;
        const bacs=new XMLHttpRequest();
        bacs.onload=function()
        {
            const telepulesek=this.responseText.split("\n");
            telepules.options.length=telepulesek.length+1;
            for(let i=0;i<telepulesek.length;i++)
            {
                telepules.options[i+1].text=telepulesek[i];
            }
        }
        bacs.open("GET","települések/bacs.txt");
        bacs.send();
    }

    if(megye.value=="Baranya")
    {
        telepules.disabled=false;
        const baranya=new XMLHttpRequest();
        baranya.onload=function()
        {
            const telepulesek=this.responseText.split("\n");
            telepules.options.length=telepulesek.length+1;
            for(let i=0;i<telepulesek.length;i++)
            {
                telepules.options[i+1].text=telepulesek[i];
            }
        }
        baranya.open("GET","települések/baranya.txt");
        baranya.send();
    }

    if(megye.value=="Békés")
    {
        telepules.disabled=false;
        const bekes=new XMLHttpRequest();
        bekes.onload=function()
        {
            const telepulesek=this.responseText.split("\n");
            telepules.options.length=telepulesek.length+1;
            for(let i=0;i<telepulesek.length;i++)
            {
                telepules.options[i+1].text=telepulesek[i];
            }
        }
        bekes.open("GET","települések/bekes.txt");
        bekes.send();
    }

    if(megye.value=="Borsod-Abaúj-Zemplén")
    {
        telepules.disabled=false;
        const borsod=new XMLHttpRequest();
        borsod.onload=function()
        {
            const telepulesek=this.responseText.split("\n");
            telepules.options.length=telepulesek.length+1;
            for(let i=0;i<telepulesek.length;i++)
            {
                telepules.options[i+1].text=telepulesek[i];
            }
        }
        borsod.open("GET","települések/borsod.txt");
        borsod.send();
    }

    if(megye.value=="Csongrád-Csanád")
    {
        telepules.disabled=false;
        const csongrad=new XMLHttpRequest();
        csongrad.onload=function()
        {
            const telepulesek=this.responseText.split("\n");
            telepules.options.length=telepulesek.length+1;
            for(let i=0;i<telepulesek.length;i++)
            {
                telepules.options[i+1].text=telepulesek[i];
            }
        }
        csongrad.open("GET","települések/csongrad.txt");
        csongrad.send();
    }

    if(megye.value=="Fejér")
    {
        telepules.disabled=false;
        const fejer=new XMLHttpRequest();
        fejer.onload=function()
        {
            const telepulesek=this.responseText.split("\n");
            telepules.options.length=telepulesek.length+1;
            for(let i=0;i<telepulesek.length;i++)
            {
                telepules.options[i+1].text=telepulesek[i];
            }
        }
        fejer.open("GET","települések/fejer.txt");
        fejer.send();
    }

    if(megye.value=="Győr-Moson-Sopron")
    {
        telepules.disabled=false;
        const gyor=new XMLHttpRequest();
        gyor.onload=function()
        {
            const telepulesek=this.responseText.split("\n");
            telepules.options.length=telepulesek.length+1;
            for(let i=0;i<telepulesek.length;i++)
            {
                telepules.options[i+1].text=telepulesek[i];
            }
        }
        gyor.open("GET","települések/gyor.txt");
        gyor.send();
    }

    if(megye.value=="Hajdú-Bihar")
    {
        telepules.disabled=false;
        const hajdu=new XMLHttpRequest();
        hajdu.onload=function()
        {
            const telepulesek=this.responseText.split("\n");
            telepules.options.length=telepulesek.length+1;
            for(let i=0;i<telepulesek.length;i++)
            {
                telepules.options[i+1].text=telepulesek[i];
            }
        }
        hajdu.open("GET","települések/hajdu.txt");
        hajdu.send();
    }

    if(megye.value=="Heves")
    {
        telepules.disabled=false;
        const heves=new XMLHttpRequest();
        heves.onload=function()
        {
            const telepulesek=this.responseText.split("\n");
            telepules.options.length=telepulesek.length+1;
            for(let i=0;i<telepulesek.length;i++)
            {
                telepules.options[i+1].text=telepulesek[i];
            }
        }
        heves.open("GET","települések/heves.txt");
        heves.send();
    }

    if(megye.value=="Jász-Nagykun-Szolnok")
    {
        telepules.disabled=false;
        const jasz=new XMLHttpRequest();
        jasz.onload=function()
        {
            const telepulesek=this.responseText.split("\n");
            telepules.options.length=telepulesek.length+1;
            for(let i=0;i<telepulesek.length;i++)
            {
                telepules.options[i+1].text=telepulesek[i];
            }
        }
        jasz.open("GET","települések/jasz.txt");
        jasz.send();
    }

    if(megye.value=="Komárom-Esztergom")
    {
        telepules.disabled=false;
        const komarom=new XMLHttpRequest();
        komarom.onload=function()
        {
            const telepulesek=this.responseText.split("\n");
            telepules.options.length=telepulesek.length+1;
            for(let i=0;i<telepulesek.length;i++)
            {
                telepules.options[i+1].text=telepulesek[i];
            }
        }
        komarom.open("GET","települések/komarom.txt");
        komarom.send();
    }

    if(megye.value=="Nógrád")
    {
        telepules.disabled=false;
        const nograd=new XMLHttpRequest();
        nograd.onload=function()
        {
            const telepulesek=this.responseText.split("\n");
            telepules.options.length=telepulesek.length+1;
            for(let i=0;i<telepulesek.length;i++)
            {
                telepules.options[i+1].text=telepulesek[i];
            }
        }
        nograd.open("GET","települések/nograd.txt");
        nograd.send();
    }

    if(megye.value=="Pest")
    {
        telepules.disabled=false;
        const pest=new XMLHttpRequest();
        pest.onload=function()
        {
            const telepulesek=this.responseText.split("\n");
            telepules.options.length=telepulesek.length+1;
            for(let i=0;i<telepulesek.length;i++)
            {
                telepules.options[i+1].text=telepulesek[i];
            }
        }
        pest.open("GET","települések/pest.txt");
        pest.send();
    }

    if(megye.value=="Somogy")
    {
        telepules.disabled=false;
        const somogy=new XMLHttpRequest();
        somogy.onload=function()
        {
            const telepulesek=this.responseText.split("\n");
            telepules.options.length=telepulesek.length+1;
            for(let i=0;i<telepulesek.length;i++)
            {
                telepules.options[i+1].text=telepulesek[i];
            }
        }
        somogy.open("GET","települések/somogy.txt");
        somogy.send();
    }

    if(megye.value=="Szabolcs-Szatmár-Bereg")
    {
        telepules.disabled=false;
        const szabolcs=new XMLHttpRequest();
        szabolcs.onload=function()
        {
            const telepulesek=this.responseText.split("\n");
            telepules.options.length=telepulesek.length+1;
            for(let i=0;i<telepulesek.length;i++)
            {
                telepules.options[i+1].text=telepulesek[i];
            }
        }
        szabolcs.open("GET","települések/szabolcs.txt");
        szabolcs.send();
    }

    if(megye.value=="Tolna")
    {
        telepules.disabled=false;
        const tolna=new XMLHttpRequest();
        tolna.onload=function()
        {
            const telepulesek=this.responseText.split("\n");
            telepules.options.length=telepulesek.length+1;
            for(let i=0;i<telepulesek.length;i++)
            {
                telepules.options[i+1].text=telepulesek[i];
            }
        }
        tolna.open("GET","települések/tolna.txt");
        tolna.send();
    }

    if(megye.value=="Vas")
    {
        telepules.disabled=false;
        const vas=new XMLHttpRequest();
        vas.onload=function()
        {
            const telepulesek=this.responseText.split("\n");
            telepules.options.length=telepulesek.length+1;
            for(let i=0;i<telepulesek.length;i++)
            {
                telepules.options[i+1].text=telepulesek[i];
            }
        }
        vas.open("GET","települések/vas.txt");
        vas.send();
    }

    if(megye.value=="Veszprém")
    {
        telepules.disabled=false;
        const veszprem=new XMLHttpRequest();
        veszprem.onload=function()
        {
            const telepulesek=this.responseText.split("\n");
            telepules.options.length=telepulesek.length+1;
            for(let i=0;i<telepulesek.length;i++)
            {
                telepules.options[i+1].text=telepulesek[i];
            }
        }
        veszprem.open("GET","települések/veszprem.txt");
        veszprem.send();
    }

    if(megye.value=="Zala")
    {
        telepules.disabled=false;
        const zala=new XMLHttpRequest();
        zala.onload=function()
        {
            const telepulesek=this.responseText.split("\n");
            telepules.options.length=telepulesek.length+1;
            for(let i=0;i<telepulesek.length;i++)
            {
                telepules.options[i+1].text=telepulesek[i];
            }
        }
        zala.open("GET","települések/zala.txt");
        zala.send();
    }
}
function kuldes()
{
    let megye= document.getElementById("megye");
    let telepules=document.getElementById("telepules");
    let tortenet=document.getElementById("tortenet");
    let cim=document.getElementById("t_cim");
    let datum_e=new Date();
    let datum=""+datum_e.getFullYear()+"."+(datum_e.getMonth()+1)+"."+datum_e.getDate()+" "+datum_e.getHours()+":"+datum_e.getMinutes()+":"+datum_e.getSeconds();
    const ajax=new XMLHttpRequest();
    ajax.onload=function()
    {
        eval(this.responseText);
        if(telepules.classList.item(1)=="is-valid" && megye.classList.item(1)=="is-valid" && tortenet.classList.item(1)=="is-valid" && cim.classList.item(1)=="is-valid")
        {
            const ajax2=new XMLHttpRequest();
            ajax2.open("GET","Történet küldése.php?cím="+cim.value+"&megye="+megye.value+"&település="+telepules.value+"&történet="+tortenet.value+"&dátum="+datum)
            ajax2.send();
            document.getElementById("kuldes").submit();
        }
    }
    ajax.open("GET","Történet ellenőrzése.php?cím="+cim.value+"&megye="+megye.value+"&település="+telepules.value+"&történet="+tortenet.value);
    ajax.send();
}
function tortenet_szerkesztes()
{
    let cim=document.getElementById("t_cim");
    if(cim.value==0)
    {
        cim.classList.add("is-invalid");
        cim.classList.remove("is-valid");
    }
    else
    {
        cim.classList.add("is-valid");
        cim.classList.remove("is-invalid");
    }
    if(cim.classList.item(1)=="is-valid")
    {
        window.open("Történet szerkesztése.php?cím="+cim.value,"_self");
    }
}
function kuldes2()
{
    let megye= document.getElementById("megye");
    let telepules=document.getElementById("telepules");
    let tortenet=document.getElementById("tortenet");
    let cim=document.getElementById("t_cim");
    let datum_e=new Date();
    let datum=""+datum_e.getFullYear()+"."+(datum_e.getMonth()+1)+"."+datum_e.getDate()+" "+datum_e.getHours()+":"+datum_e.getMinutes()+":"+datum_e.getSeconds();
    const ajax=new XMLHttpRequest();
    ajax.onload=function()
    {
        eval(this.responseText);
        if(telepules.classList.item(1)=="is-valid" && megye.classList.item(1)=="is-valid" && tortenet.classList.item(1)=="is-valid" && cim.classList.item(1)=="is-valid")
        {
            const ajax2=new XMLHttpRequest();
            ajax2.open("POST","Történet frissítése.php");
            ajax2.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
            ajax2.send("cím="+cim.value+"&megye="+megye.value+"&település="+telepules.value+"&történet="+tortenet.value+"&dátum="+datum);
            document.getElementById("kuldes").submit();
        }
    }
    ajax.open("GET","Történet frissítés ellenőrzése.php?cím="+cim.value+"&megye="+megye.value+"&település="+telepules.value+"&történet="+tortenet.value);
    ajax.send();
}

function torles2()
{
    const ajax=new XMLHttpRequest();
    ajax.open("GET","Történet törlése.php");
    ajax.onreadystatechange=function()
    {
        window.open("Fiók szerkesztése.php","_self")
    }
    ajax.send();
}