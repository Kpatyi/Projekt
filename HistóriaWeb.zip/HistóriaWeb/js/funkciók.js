function parallax()
{
    let ertek=window.scrollY;
    if(ertek>=0)
    {
        document.getElementById("cim").style.marginTop=ertek*2+'px';
        document.getElementById("jf").style.marginTop=ertek*-1+'px';
        document.getElementById("jf").style.marginLeft=ertek*1+'px';
        document.getElementById("bf").style.marginTop=ertek*-1+'px';
        document.getElementById("bf").style.marginLeft=ertek*-1+'px';
        document.getElementById("ba").style.marginTop=ertek*1+'px';
        document.getElementById("ba").style.marginLeft=ertek*-1+'px';
        document.getElementById("ja").style.marginTop=ertek*1+'px';
        document.getElementById("ja").style.marginLeft=ertek*1+'px';
    }

}

function torles()
{
    const ajax=new XMLHttpRequest();
    ajax.open("GET","Törlés.php");
    ajax.send();
}

function mutasd_j()
{
    let jelszo=document.getElementById("jelszo");
    let mutasd_j=document.getElementById("mutasd_j");
    if(jelszo.type==="password")
    {
        jelszo.type="text";
        mutasd_j.classList.replace("bi-eye-fill","bi-eye-slash-fill")
    }
    else{
        jelszo.type="password";
        mutasd_j.classList.replace("bi-eye-slash-fill","bi-eye-fill")
    }
}

function mutasd_j_i()
{
    let jelszo=document.getElementById("jelszo_i");
    let mutasd_j=document.getElementById("mutasd_j_i");
    if(jelszo.type=="password")
    {
        jelszo.type="text";
        mutasd_j.classList.replace("bi-eye-fill","bi-eye-slash-fill");
    }
    else{
        jelszo.type="password";
        mutasd_j.classList.replace("bi-eye-slash-fill","bi-eye-fill");
    }
}

function helyek()
{
    const ajax=new XMLHttpRequest();
    ajax.onload=function()
    {
        const egesz=this.responseText;
        document.getElementById("helyek").innerHTML=egesz;
    }
    ajax.open("GET","Helyek.php");
    ajax.send()
}

function torles2()
{
    const ajax=new XMLHttpRequest();
    ajax.open("GET","Történet törlése.php");
    ajax.onreadystatechange=function()
    {
        window.open("Fiók szerkesztése.php","_self")
    }
    ajax.send();
}

function szamolas(){
    let oldal=document.getElementById("oldal").innerText
    const ajax=new XMLHttpRequest();
    ajax.open("GET","Megtekintés számláló.php?oldal="+oldal);
    ajax.send()
}

function tortenetek()
{
    const ajax=new XMLHttpRequest();
    ajax.onload=function()
    {
        if(this.responseText=="0")
        {
            window.open("Térkép.html","_self");
        }
        if(this.responseText=="1")
        {
            window.open("Térkép.php","_self");
        }
        document.getElementById("tortenet1").innerHTML=this.responseText;
    }
    ajax.open("GET","Történetek frissítése.php");
    ajax.send();
}

function kijelentkezes()
{
    const ajax=new XMLHttpRequest();
    ajax.onload=function()
    {
        if(this.responseText=="0")
        {
            window.open("Főoldal.html","_self");
        }
        setInterval(kijelentkezes(),1);
    }
    ajax.open("GET","Bejelentkezés ellenőrzése.php");
    ajax.send();
}

function kereses_m() 
{
    let nincs=0;
    const szo = document.getElementById("megye");
    const nagybetu = szo.value.toUpperCase();
    const lehetosegek = document.querySelectorAll("#lehetosegek1 li");
    for (let i = 0; i < lehetosegek.length; i++) 
    {
        txtValue = lehetosegek[i].textContent || lehetosegek[i].innerText;
        if (txtValue.toUpperCase().indexOf(nagybetu) > -1) 
        {
            lehetosegek[i].style.display = "block";
        } 
        else
        {
            nincs++;
            lehetosegek[i].style.display = "none";
        }
    }

    if(nincs==lehetosegek.length)
    {
        document.getElementById("lehetosegek1").innerHTML+="<li id='nincs' class='dropdown-item'>Nincs találat</li>"
    }
    else
    {
        let osszes=document.querySelectorAll("#lehetosegek1 #nincs");
        for(let i=0;i<osszes.length;i++)
        {
            osszes[i].remove();
        }
    }
}

function kereses_t() 
{
    let nincs=0;
    const szo = document.getElementById("telepules");
    const nagybetu = szo.value.toUpperCase().trim();
    const lehetosegek = document.querySelectorAll("#lehetosegek2 li");
    for (let i = 0; i < lehetosegek.length; i++) 
    {
        txtValue = lehetosegek[i].textContent || lehetosegek[i].innerText;
        if (txtValue.toUpperCase().indexOf(nagybetu) > -1) 
        {
            lehetosegek[i].style.display = "block";
        } 
        else
        {
            nincs++;
            lehetosegek[i].style.display = "none";
        }
    }

    if(nincs==lehetosegek.length)
    {
        document.getElementById("lehetosegek2").innerHTML+="<li id='nincs' class='dropdown-item'>Nincs találat</li>"
    }
    else
    {
        let osszes=document.querySelectorAll("#lehetosegek2 #nincs");
        for(let i=0;i<osszes.length;i++)
        {
            osszes[i].remove();
        }
    }
}

function kereses_to() 
{
    let nincs=0;
    const szo = document.getElementById("tortenet");
    const nagybetu = szo.value.toUpperCase().trim();
    const lehetosegek = document.querySelectorAll("#lehetosegek li");
    for (let i = 0; i < lehetosegek.length; i++) 
    {
        txtValue = lehetosegek[i].textContent || lehetosegek[i].innerText;
        if (txtValue.toUpperCase().indexOf(nagybetu) > -1) 
        {
            lehetosegek[i].style.display = "block";
        } 
        else
        {
            nincs++;
            lehetosegek[i].style.display = "none";
        }
    }

    if(nincs==lehetosegek.length)
    {
        document.getElementById("lehetosegek").innerHTML+="<li id='nincs' class='dropdown-item'>Nincs találat</li>"
    }
    else
    {
        let osszes=document.querySelectorAll("#lehetosegek #nincs");
        for(let i=0;i<osszes.length;i++)
        {
            osszes[i].remove();
        }
    }
}

function valasztot_m(megye)
{
    document.getElementById("megye").value=megye;
}

function feltolt_t()
{
    let megye=document.getElementById("megye").value;
    let telepules=document.getElementById("lehetosegek2");
    let van=false;
    if(megye.trim()=="")
    {
        telepules.innerHTML="<li id='nincs_m' class='dropdown-item'>Még nem választotál megyét</li>"
    }
    else
    {
        if(document.getElementById("nincs_m")!=null)
        {
            document.getElementById("nincs_m").remove();
        }
        const megyek=document.querySelectorAll(".megyek li");
        for(let i=0;i<megyek.length;i++)
        {
            if(megye==megyek[i].innerHTML)
            {
                van=true;
                const ajax=new XMLHttpRequest();
                ajax.onload=function()
                {
                    const telepulesek=this.responseText.split("\n");
                    let telepulesek1="";
                    for(let j=0;j<telepulesek.length;j++)
                    {
                        telepulesek1+="<li onclick='valasztot_t("+'"'+telepulesek[j].trim()+'"'+")' class='dropdown-item'>"+telepulesek[j]+"</li>"
                    }
                    document.getElementById("lehetosegek2").innerHTML=telepulesek1;
                }
                ajax.open("GET","települések/"+megye.trim()+".txt");
                ajax.send();
                break;
            }
        }
        if(van==false)
        {
            document.getElementById("lehetosegek2").innerHTML="<li id='nincs_m' class='dropdown-item'>Még nem választotál megyét</li>";
        }
    }
}

function valasztot_t(telepules)
{
    document.getElementById("telepules").value=telepules;
}

function valasztot_to(cim)
{
    document.getElementById("t_cim").value=cim;
}

function van_cim()
{
    cim=document.getElementById("t_cim");
    const ajax=new XMLHttpRequest();
    ajax.onload=function()
    {
        eval(this.responseText);
        if(cim.classList.item(2)=="is-valid")
        {
            window.open("Történet szerkesztése.php?cím="+cim.value,"_self")
        }
    }
    ajax.open("GET","Cím ellenőrzése.php?cím="+cim.value);
    ajax.send();
}