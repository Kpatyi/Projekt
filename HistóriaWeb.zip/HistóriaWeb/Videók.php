<?php 
session_start();
$felhasznalonev=$_SESSION["felhasználónév"];
$jelszo=$_SESSION["jelszó"];
if($felhasznalonev==null)
{
  header("Location:Bejelentkezés.html");
}
echo "
  <nav class='navbar navbar-expand-md navbar-dark'> 
    <div class='container-fluid'>
      <a class='navbar-brand' href='Főoldal.php'>
        <img src='Képek/Logo.png' width='100px'>
      </a>
      <button class='navbar-toggler' type='button' data-bs-toggle='collapse' data-bs-target='#navbar'>
        <span class='navbar-toggler-icon'></span>
      </button>
      <div class='collapse navbar-collapse justify-content-start' id='navbar'>
        <ul class='navbar-nav'>
          <li class='nav-item'>
            <a class='nav-link me-5 text-light' href='Képek.php'>Képek</a>
          </li>
          <li class='nav-item'>
            <a class='nav-link me-5 text-light' href='Videók.php'>Videók</a>
          </li>
          <li class='nav-item'>
            <a class='nav-link me-5 text-light' href='Térkép.php'>Térkép</a>
          </li>     
        </ul>
      </div>
      <div class='collapse navbar-collapse justify-content-end' id='navbar'>
        <ul class='navbar-nav'>
          <li class='nav-item dropdown'>
            <a class='nav-link me-5 text-light dropdown-toggle' href='#' role='button' data-bs-toggle='dropdown'>$felhasznalonev</a>
            <ul class='dropdown-menu dropdown-menu-end'>
              <li><a class='dropdown-item' href='Fiók szerkesztése.php'>Fiók szerkesztése</a></li>
              <li><a class='dropdown-item' href='Történet írása.php'>Történet írása</a></li>
              <li><a class='dropdown-item' href='Kijelentkezés.php'>Kijelentkezés</a></li>
            </ul>
          </li>
        </ul>
      </div>
    </div>
  </nav>
"
?>
<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/formázások.css">
    <script src="bootstrap/js/bootstrap.min.js"></script>
    <link rel="icon" type="image/x-icon" href="Képek/Logo.png">
    <script src="js/funkciók.js"></script>
    <title id="oldal">Videók</title>
</head>
<body onload="szamolas();kijelentkezes()">
  <h1 id="r_b" class="text-light text-center">Tarpa</h1>
  <div class="d-flex justify-content-center mt-5 mb-5">
    <video controls class="img-thumbnail w-75">
      <source src="Videók/Tarpa1.mp4" type="video/mp4">
    </video>
  </div>
  <h1 id="r_b" class="text-light text-center">Fehérgyarmat</h1>
  <div class="d-flex justify-content-center mt-5 mb-5">
    <video controls class="img-thumbnail w-75">
      <source src="" type="video/mp4">
    </video>
  </div>
</body>
</html>