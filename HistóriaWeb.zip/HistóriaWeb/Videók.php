<?php 
session_start();
$felhasznalonev=$_SESSION["felhasználónév"];
$jelszo=$_SESSION["jelszó"];
echo "
  <nav class='navbar navbar-expand-sm navbar-dark' onload='preventBack()'> 
    <div class='container-fluid'>
      <a class='navbar-brand' href='Főoldal.php'>
        <img src='Képek/Logo.png' width='100px'>
      </a>
      <button class='navbar-toggler' type='button' data-bs-toggle='collapse' data-bs-target='#navbar'>
        <span class='navbar-toggler-icon'></span>
      </button>
      <div class='collapse navbar-collapse justify-content-start' id='navbar'>
        <ul class='navbar-nav'>
          <li class='nav-item'>
            <a class='nav-link' href='Képek.php'>Képek</a>
          </li>
          <li class='nav-item'>
            <a class='nav-link' href='Videók.php'>Videók</a>
          </li>
          <li class='nav-item'>
            <a class='nav-link' href='Térkép.php'>Térkép</a>
          </li>     
        </ul>
      </div>
      <div class='collapse navbar-collapse justify-content-end' id='navbar'>
        <ul class='navbar-nav'>
          <li class='nav-item dropdown'>
            <a class='nav-link dropdown-toggle' href='#' role='button' data-bs-toggle='dropdown'>$felhasznalonev</a>
            <ul class='dropdown-menu dropdown-menu-end'>
              <li><a class='dropdown-item' href='Fiók szerkesztése.php'>Fiók szerkesztése</a></li>
              <li><a class='dropdown-item' href=''>Történet írása</a></li>
              <li><a class='dropdown-item' href='Főoldal.html'>Kijelentkezés</a></li>
            </ul>
          </li>
        </ul>
      </div>
    </div>
  </nav>
"
?>
<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/formázások.css">
    <script src="bootstrap/js/bootstrap.min.js"></script>
    <link rel="icon" type="image/x-icon" href="Képek/Logo.png">
    <title>Videók</title>
</head>
<body>
    <video controls class="img-thumbnail video">
        <source src="" type="video/mp4">
    </video>
    <video controls class="img-thumbnail video">
    <source src="" type="video/mp4">
  </video>
</body>
</html>