<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/gombok formása.css">
    <link rel="stylesheet" href="css/formázások.css">
    <script src="bootstrap/js/bootstrap.min.js"></script>
    <script src="js/funkciók.js"></script>
    <title id="oldal">Történet írása</title>
</head>
<?php
session_start();
$felhasznalonev=$_SESSION["felhasználónév"];
if($felhasznalonev==null)
{
  header("Location:Bejelentkezés.html");
}
echo
"
<body onload='szamolas();kijelentkezes()'>
    <nav class='navbar navbar-expand-sm navbar-dark'>
        <div class='container-fluid'>
            <a class='navbar-brand' href='Főoldal.php'>
                <img src='Képek/Logo.png' width='100px'>
            </a>
            <button class='navbar-toggler' type='button' data-bs-toggle='collapse' data-bs-target='#navbar'>
                <span class='navbar-toggler-icon'></span>
            </button>
            <div class='collapse navbar-collapse justify-content-start' id='navbar'>
                <ul class='navbar-nav'>
                    <li class='nav-item'>
                        <a class='nav-link me-5 text-light' href='Képek.php'>Képek</a>
                    </li>
                    <li class='nav-item'>
                        <a class='nav-link me-5 text-light' href='Videók.php'>Videók</a>
                    </li>
                    <li class='nav-item'>
                        <a class='nav-link me-5 text-light' href='Térkép.php'>Térkép</a>
                    </li>     
                </ul>
            </div>
            <div class='collapse navbar-collapse justify-content-end' id='navbar'>
                <ul class='navbar-nav'>
                    <li class='nav-item dropdown'>
                        <a class='nav-link me-5 text-light dropdown-toggle' href='#' role='button' data-bs-toggle='dropdown'>$felhasznalonev</a>
                        <ul class='dropdown-menu dropdown-menu-end'>
                            <li><a class='dropdown-item' href='Fiók szerkesztése.php'>Fiók szerkesztése</a></li>
                            <li><a class='dropdown-item' href='Történet írása.php'>Történet írása</a></li>
                            <li><a class='dropdown-item' href='Kijelentkezés.php'>Kijelentkezés</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <h1 id='r_b' class='text-center'>Történet írása</h1>
    <form action='Megye.php' method='get' class='m-auto needs-validation w-75' id='kuldes' onsubmit='event.preventDefault();kuldes()'>
        <div class='container'>
            <div class='row'>
                <div class='col-6'>
                    <div class='form-floating mb-5'>
                        <select class='form-select' name='megye' id='megye' onchange='feltolt()' required>
                            <option value='0'>Válasz egy megyét...</option>
                            <option value='Bács-Kiskun'>Bács-Kiskun megye</option>
                            <option value='Baranya'>Baranya megye</option>
                            <option value='Békés'>Békés megye</option>
                            <option value='Borsod-Abaúj-Zemplén'>Borsod-Abaúj-Zemplén megye</option>
                            <option value='Csongrád-Csanád'>Csongrád-Csanád megye</option>
                            <option value='Fejér'>Fejér megye</option>
                            <option value='Győr-Moson-Sopron'>Győr-Moson-Sopron megye</option>
                            <option value='Hajdú-Bihar'>Hajdú-Bihar megye</option>
                            <option value='Heves'>Heves megye</option>
                            <option value='Jász-Nagykun-Szolnok'>Jász-Nagykun-Szolnok megye</option>
                            <option value='Komárom-Esztergom'>Komárom-Esztergom megye</option>
                            <option value='Nógrád'>Nógrád megye</option>
                            <option value='Pest'>Pest megye</option>
                            <option value='Somogy'>Somogy megye</option>
                            <option value='Szabolcs-Szatmár-Bereg'>Szabolcs-Szatmár-Bereg megye</option>
                            <option value='Tolna'>Tolna megye</option>
                            <option value='Vas'>Vas megye</option>
                            <option value='Veszprém'>Veszprém megye</option>
                            <option value='Zala'>Zala megye</option>
                        </select>
                        <label for='megye' class='form-label'>Megye:</label>
                        <div class='invalid-tooltip'>
                            Válasz megyét
                        </div>
                    </div>
                </div>
                <div class='col-6'>
                    <div class='form-floating'>
                        <select class='form-select' id='telepules' name='település' disabled required>
                            <option value='0'>Válasz egy települést...</option>
                        </select>
                        <label for='telepules' class='form-label'>Település:</label>
                        <div class='invalid-tooltip'>
                            Válasz települést
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class='form-floating'>
            <input type='text' class='form-control' name='cim' id='t_cim'>
            <label class='form-label' for='t_cim'>Cím</label>
            <div class='invalid-tooltip' id='c_v'>
            </div>
        </div>
        <div class='form-floating mb-5'>
            <textarea class='form-control' id='tortenet' name='tortenet' style='height: 350px;' placeholder='Történet'></textarea>
            <label for='tortenet'>Történet</label>
            <div class='invalid-tooltip' id='t_v'>
            </div>
        </div>
        <div class='container'>
            <div class='row'>
                <div class='col-6 d-flex justify-content-start'>
                    <a href='Főoldal.php'>
                        <button class='btn btn-primary me-5' type='button'>Vissza</button>
                    </a>
                </div>
                <div class='col-6 d-flex justify-content-end'>
                    <button class='btn btn-primary' type='submit'>Küldés</button>
                </div>
            </div>
        </div>
    </form>
</body>
";
?>