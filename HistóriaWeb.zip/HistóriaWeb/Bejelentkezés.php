<?php
session_start();
$_SESSION["felhasználónév"]=$_POST["felhasználónév"];
$_SESSION["jelszó"]=$_POST["jelszó"];
header("Location: Főoldal.php");
?>