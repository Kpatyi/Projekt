<?php
    $adatbazis="adatok";
    $hostname="localhost";
    $adatbazis_felhasznalonev="root";
    $adatbazis_jelszo="";
    $kapcsolat= mysqli_connect($hostname,$adatbazis_felhasznalonev,$adatbazis_jelszo,$adatbazis);
    if(!$kapcsolat)
    {
        die("Sikertelen kapcsolódás: ".mysqli_connect_error());
    }
    $email=$_POST["email"];
    $felhasznalonev=$_POST["felhasználónév"];
    $jelszo=$_POST["jelszó"];
    
    $idik_l="SELECT id FROM fiókok ORDER BY id";
    $idik=$kapcsolat->query($idik_l);
    $id=1;
    while($sor=$idik->fetch_assoc())
    {
        if($sor["id"]==$id)
        {
            $id++;
        }
        else
        {
            break;
        }
    }
    $bekuldes="INSERT INTO fiókok(id,felhasználónevek,jelszavak,email) VALUES($id,'$felhasznalonev','$jelszo','$email')";
    $kapcsolat->query($bekuldes);
    header("Location: Főoldal.php")
?>