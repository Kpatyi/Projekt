<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/formázások.css">
    <script src="bootstrap/js/bootstrap.min.js"></script>
    <script src="js/funkciók.js"></script>
    <title>Történetek</title>
</head>
<body onscroll="parallex2()">
</body>
<?php
    $adatbazis="adatok";
    $hostname="localhost";
    $adatbazis_felhasznalonev="root";
    $adatbazis_jelszo="";
    $kapcsolat= mysqli_connect($hostname,$adatbazis_felhasznalonev,$adatbazis_jelszo,$adatbazis);
    if(!$kapcsolat)
    {
        die("Sikertelen kapcsolódás: ".mysqli_connect_error());
    }
    session_start();
    if(!isset($_SESSION["megye"]))
    {
        header("Location:Térkép.html");
    }
    else
    {
        $megye=$_SESSION["megye"];
    }
    if(isset($_SESSION["felhasználónév"]))
    {
        $felhasznalonev_s=$_SESSION["felhasználónév"];
        echo
        "
        <nav class='navbar navbar-expand-sm navbar-dark'>
            <div class='container-fluid'>
                    <a class='navbar-brand' href='Főoldal.php'>
                        <img src='Képek/Logo.png' width='100px'>
                    </a>
                    <button class='navbar-toggler' type='button' data-bs-toggle='collapse' data-bs-target='#navbar'>
                        <span class='navbar-toggler-icon'></span>
                    </button>
                <div class='collapse navbar-collapse justify-content-start' id='navbar'>
                    <ul class='navbar-nav'>
                        <li class='nav-item'>
                            <a class='nav-link' href='Képek.php'>Képek</a>
                        </li>
                        <li class='nav-item'>
                            <a class='nav-link' href='Videók.php'>Videók</a>
                        </li>
                        <li class='nav-item'>
                            <a class='nav-link' href='Térkép.php'>Térkép</a>
                        </li>     
                    </ul>
                </div>
                <div class='collapse navbar-collapse justify-content-end' id='navbar'>
                    <ul class='navbar-nav'>
                        <li class='nav-item dropdown'>
                            <a class='nav-link dropdown-toggle' href='#' role='button' data-bs-toggle='dropdown'>$felhasznalonev_s</a>
                            <ul class='dropdown-menu dropdown-menu-end'>
                                <li><a class='dropdown-item' href='Fiók szerkesztése.php'>Fiók szerkesztése</a></li>
                                <li><a class='dropdown-item' href='Történet írása.php'>Történet írása</a></li>
                                <li><a class='dropdown-item' href='Kijelentkezés.php'>Kijelentkezés</a></li>
                            </ul>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
        <div class='d-flex justify-content-center align-items-center parallex'>
            <h1 id='cim2'>$megye megye</h1>
            <img src='Képek/Bal_also.png' id='ba'>
            <img src='Képek/Jobb_also.png' id='ja'>
            <img src='Képek/Bal_felso.png' id='bf'>
            <img src='Képek/Jobb_felso.png' id='jf'>
        </div>
        ";
    }
    else
    {
        echo
        "
        <nav class='navbar navbar-expand-md navbar-dark'>
            <div class='container-fluid'>
                    <a class='navbar-brand' href='Főoldal.php'>
                        <img src='Képek/Logo.png' width='100px'>
                    </a>
                    <button class='navbar-toggler' type='button' data-bs-toggle='collapse' data-bs-target='#navbar'>
                        <span class='navbar-toggler-icon'></span>
                    </button>
                <div class='collapse navbar-collapse justify-content-start' id='navbar'>
                    <ul class='navbar-nav'>
                        <li class='nav-item'>
                            <a class='nav-link' href='Képek.html'>Képek</a>
                        </li>
                        <li class='nav-item'>
                            <a class='nav-link' href='Videók.html'>Videók</a>
                        </li>
                        <li class='nav-item'>
                            <a class='nav-link' href='Térkép.html'>Térkép</a>
                        </li>     
                    </ul>
                </div>
                <div class='collapse navbar-collapse justify-content-end' id='navbar'>
                    <ul class='navbar-nav'>
                        <li class='nav-item'>
                            <a href='Regisztráció.html' class='nav-link'>Regisztráció</a>
                        </li>
                        <li class='nav-item'>
                            <a href='Bejelentkezés.html' class='nav-link'>Bejelentkezés</a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
        <div class='d-flex justify-content-center align-items-center parallex'>
            <h1 id='cim2'>$megye megye</h1>
            <img src='Képek/Bal_also.png' id='ba'>
            <img src='Képek/Jobb_also.png' id='ja'>
            <img src='Képek/Bal_felso.png' id='bf'>
            <img src='Képek/Jobb_felso.png' id='jf'>
        </div>
        ";
    }
    $telepulesek_l="SELECT DISTINCT települések FROM történetek WHERE megyék='$megye' ORDER BY települések";
    $telepulesek=$kapcsolat->query($telepulesek_l);
    while($sor1=$telepulesek->fetch_assoc())
    {
        $telepules=$sor1["települések"];
        echo 
            "
            <div class='tartalom'>
                <h2>$telepules</h2>
                <br>
            ";
        $tortenetek_l="SELECT cím,történet_hely,f_id,dátum FROM történetek WHERE települések='$telepules'";
        $tortenetek=$kapcsolat->query($tortenetek_l);
        while($sor2=$tortenetek->fetch_assoc())
        {
            $id=$sor2["f_id"];
            $datum=$sor2["dátum"];
            $cim=$sor2["cím"];
            $felhasznalonev_l="SELECT felhasználónevek FROM fiókok WHERE id='$id'";
            $felhasznalonev_e=$kapcsolat->query($felhasznalonev_l);
            $felhasznalonev_egesz=$felhasznalonev_e->fetch_assoc();
            $felhasznalonev=$felhasznalonev_egesz["felhasználónevek"];
            $fajl=fopen("történetek/".$sor2["történet_hely"],"r");
            $tortenet=fread($fajl,filesize("történetek/".$sor2["történet_hely"]));
            fclose($fajl);
            echo 
                "
                    <h3 class='d-flex justify-content-center'>$cim</h3>
                    <p>$tortenet</p>
                    <div class='d-flex justify-content-end'>
                        $felhasznalonev $datum
                    </div>
                    <br>
                ";
        }
        echo
            "
            </div>
            ";
    }
?>