<?php 
session_start();
$felhasznalonev=$_SESSION["felhasználónév"];
$jelszo=$_SESSION["jelszó"];
if($felhasznalonev==null)
{
  header("Location:Bejelentkezés.html");
}
echo "
  <nav class='navbar navbar-expand-md navbar-dark' onload='preventBack()'>
    <div class='container-fluid'>
      <a class='navbar-brand' href='Főoldal.php'>
        <img src='Képek/Logo.png' width='100px'>
      </a>
      <button class='navbar-toggler' type='button' data-bs-toggle='collapse' data-bs-target='#navbar'>
        <span class='navbar-toggler-icon'></span>
      </button>
      <div class='collapse navbar-collapse justify-content-start' id='navbar'>
        <ul class='navbar-nav'>
          <li class='nav-item'>
            <a class='nav-link' href='Képek.php'>Képek</a>
          </li>
          <li class='nav-item'>
            <a class='nav-link' href='Videók.php'>Videók</a>
          </li>
          <li class='nav-item'>
            <a class='nav-link' href='Térkép.php'>Térkép</a>
          </li>     
        </ul>
      </div>
      <div class='collapse navbar-collapse justify-content-end' id='navbar'>
        <ul class='navbar-nav'>
          <li class='nav-item dropdown'>
            <a class='nav-link dropdown-toggle' href='#' role='button' data-bs-toggle='dropdown'>$felhasznalonev</a>
            <ul class='dropdown-menu dropdown-menu-end'>
              <li><a class='dropdown-item' href='Fiók szerkesztése.php'>Fiók szerkesztése</a></li>
              <li><a class='dropdown-item' href='Történet írása.php'>Történet írása</a></li>
              <li><a class='dropdown-item' href='Kijelentkezés.php'>Kijelentkezés</a></li>
            </ul>
          </li>
        </ul>
      </div>
    </div>
  </nav>
"
?>
<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/formázások.css">
    <script src="bootstrap/js/bootstrap.min.js"></script>
    <title>Képek</title>
</head>
<body>
    <div id="panel" class="carousel slide" data-bs-ride="carousel">
        <div class="carousel-inner">
            <div class="carousel-item active">
                <img src="Képek/Példa1.jpg" class="d-block">
            </div>
            <div class="carousel-item">
                <img src="Képek/Példa2.jpg" class="d-block">
            </div>
            <div class="carousel-item">
                <img src="Képek/térkép.jpg" class="d-block">
            </div>
        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#panel" data-bs-slide="prev">
            <span class="carousel-control-prev-icon"></span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#panel" data-bs-slide="next">
            <span class="carousel-control-next-icon"></span>
        </button>
    </div>
</body>
</html>