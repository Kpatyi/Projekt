<?php
$adatbazis="adatok";
$hostname="localhost";
$adatbazis_felhasznalonev="root";
$adatbazis_jelszo="";
$kapcsolat= mysqli_connect($hostname,$adatbazis_felhasznalonev,$adatbazis_jelszo,$adatbazis);
if(!$kapcsolat)
{
    die("Sikertelen kapcsolódás: ".mysqli_connect_error());
}
session_start();
if(!isset($_SESSION["megye"]))
{
    header("Location:Térkép.html");
}
else
{
    $megye=$_SESSION["megye"];
}
$megye_l="SELECT * FROM történetek WHERE megyék='$megye'";
$van_e=$kapcsolat->query($megye_l)->num_rows;
if($van_e>0)
{
$telepulesek_l="SELECT DISTINCT települések FROM történetek WHERE megyék='$megye' ORDER BY települések";
$telepulesek=$kapcsolat->query($telepulesek_l);
while($sor1=$telepulesek->fetch_assoc())
{
    $telepules=$sor1["települések"];
    echo 
        "
        <div class='tartalom position-relative w-100 text-light ps-4 pe-4'>
            <h2>$telepules</h2>
            <br>
        ";
    $tortenetek_l="SELECT cím,történet_hely,f_id,dátum FROM történetek WHERE települések='$telepules'";
    $tortenetek=$kapcsolat->query($tortenetek_l);
    while($sor2=$tortenetek->fetch_assoc())
    {
        $id=$sor2["f_id"];
        $datum=$sor2["dátum"];
        $cim=$sor2["cím"];
        $felhasznalonev_l="SELECT felhasználónevek FROM fiókok WHERE id='$id'";
        $felhasznalonev_e=$kapcsolat->query($felhasznalonev_l);
        $felhasznalonev_egesz=$felhasznalonev_e->fetch_assoc();
        $felhasznalonev=$felhasznalonev_egesz["felhasználónevek"];
        $fajl=fopen("történetek/".$sor2["történet_hely"],"r");
        $tortenet=fread($fajl,filesize("történetek/".$sor2["történet_hely"]));
        fclose($fajl);
        echo 
            "
                <h3 class='d-flex justify-content-center'>$cim</h3>
                <br>
                <p>$tortenet</p>
                <div class='d-flex justify-content-end mb-5'>
                    $felhasznalonev $datum
                </div>
            ";
    }
    echo
        "
        </div>
        ";
}
}
else
{
    if(isset($_SESSION["felhasználónév"]))
    {
        echo"1";
    }
    else
    {
        echo"0";
    }
}
?>