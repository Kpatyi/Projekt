<?php
$adatbazis="adatok";
$hostname="localhost";
$adatbazis_felhasznalonev="root";
$adatbazis_jelszo="";
$kapcsolat= mysqli_connect($hostname,$adatbazis_felhasznalonev,$adatbazis_jelszo,$adatbazis);
if(!$kapcsolat)
{
    die("Sikertelen kapcsolódás: ".mysqli_connect_error());
}
$helyek="SELECT DISTINCT megyék FROM történetek";
$eredmeny=$kapcsolat->query($helyek);
$megyek=array();
$kiir="";
while($sor=$eredmeny->fetch_assoc())
{
    array_push($megyek,$sor["megyék"]);
}
for($i=0;$i<count($megyek);$i++)
{
    if($i==count($megyek)-1)
    {
        if($megyek[$i]=="Szabolcs-Szatmár-Bereg megye")
        {
            $kiir.="#szabolcs";
        }
        else
        {
            if($megyek[$i]=="Borsod-Abaúj-Zemplén megye")
            {
                $kiir.="#borsod";
            }
            else
            {
                if($megyek[$i]=="Hajdú-Bihar megye")
                {
                    $kiir.="#hajdu";
                }
                else
                {
                    if($megyek[$i]=="Békés megye")
                    {
                        $kiir.="#bekes";
                    }
                    else
                    {
                        if($megyek[$i]=="Csongrád-Csanád megye")
                        {
                            $kiir.="#csongrad";
                        }
                        else
                        {
                            if($megyek[$i]=="Jász-Nagykun-Szolnok megye")
                            {
                                $kiir.="#jasz";
                            }
                            else
                            {
                                if($megyek[$i]=="Heves megye")
                                {
                                    $kiir.="#heves";
                                }
                                else
                                {
                                    if($megyek[$i]=="Nógrád megye")
                                    {
                                        $kiir.="#nograd";
                                    }
                                    else
                                    {
                                        if($megyek[$i]=="Pest megye")
                                        {
                                            $kiir.="#pest";
                                        }
                                        else
                                        {
                                            if($megyek[$i]=="Bács-Kiskun megye")
                                            {
                                                $kiir.="#bacs";
                                            }
                                            else
                                            {
                                                if($megyek[$i]=="Komárom-Esztergom megye")
                                                {
                                                    $kiir.="#komarom";
                                                }
                                                else
                                                {
                                                    if($megyek[$i]=="Fejér megye")
                                                    {
                                                        $kiir.="#fejer";
                                                    } 
                                                    else
                                                    {
                                                        if($megyek[$i]=="Tolna megye")
                                                        {
                                                            $kiir.="#tolna";
                                                        }
                                                        else
                                                        {
                                                            if($megyek[$i]=="Baranya megye")
                                                            {
                                                                $kiir.="#baranya";
                                                            }
                                                            else
                                                            {
                                                                if($megyek[$i]=="Somogy megye")
                                                                {
                                                                    $kiir.="#somogy";
                                                                }
                                                                else
                                                                {
                                                                    if($megyek[$i]=="Veszprém megye")
                                                                    {
                                                                        $kiir.="#veszprem";
                                                                    }
                                                                    else
                                                                    {
                                                                        if($megyek[$i]=="Győr-Moson-Sopron megye")
                                                                        {
                                                                            $kiir.="#gyor";
                                                                        }
                                                                        else
                                                                        {
                                                                            if($megyek[$i]=="Vas megye")
                                                                            {
                                                                                $kiir.="#vas";
                                                                            }
                                                                            else
                                                                            {
                                                                                if($megyek[$i]=="Zala megye")
                                                                                {
                                                                                    $kiir.="#zala";
                                                                                }
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }   
                            }
                        }
                    }    
                }
            }
        }
    }
    else
    {
        if($megyek[$i]=="Szabolcs-Szatmár-Bereg megye")
        {
            $kiir.="#szabolcs,";
        }
        else
        {
            if($megyek[$i]=="Borsod-Abaúj-Zemplén megye")
            {
                $kiir.="#borsod,";
            }
            else
            {
                if($megyek[$i]=="Hajdú-Bihar megye")
                {
                    $kiir.="#hajdu,";
                }
                else
                {
                    if($megyek[$i]=="Békés megye")
                    {
                        $kiir.="#bekes,";
                    }
                    else
                    {
                        if($megyek[$i]=="Csongrád-Csanád megye")
                        {
                            $kiir.="#csongrad,";
                        }
                        else
                        {
                            if($megyek[$i]=="Jász-Nagykun-Szolnok megye")
                            {
                                $kiir.="#jasz,";
                            }
                            else
                            {
                                if($megyek[$i]=="Heves megye")
                                {
                                    $kiir.="#heves,";
                                }
                                else
                                {
                                    if($megyek[$i]=="Nógrád megye")
                                    {
                                        $kiir.="#nograd,";
                                    }
                                    else
                                    {
                                        if($megyek[$i]=="Pest megye")
                                        {
                                            $kiir.="#pest,";
                                        }
                                        else
                                        {
                                            if($megyek[$i]=="Bács-Kiskun megye")
                                            {
                                                $kiir.="#bacs,";
                                            }
                                            else
                                            {
                                                if($megyek[$i]=="Komárom-Esztergom megye")
                                                {
                                                    $kiir.="#komarom,";
                                                }
                                                else
                                                {
                                                    if($megyek[$i]=="Fejér megye")
                                                    {
                                                        $kiir.="#fejer,";
                                                    } 
                                                    else
                                                    {
                                                        if($megyek[$i]=="Tolna megye")
                                                        {
                                                            $kiir.="#tolna,";
                                                        }
                                                        else
                                                        {
                                                            if($megyek[$i]=="Baranya megye")
                                                            {
                                                                $kiir.="#baranya,";
                                                            }
                                                            else
                                                            {
                                                                if($megyek[$i]=="Somogy megye")
                                                                {
                                                                    $kiir.="#somogy,";
                                                                }
                                                                else
                                                                {
                                                                    if($megyek[$i]=="Veszprém megye")
                                                                    {
                                                                        $kiir.="#veszprem,";
                                                                    }
                                                                    else
                                                                    {
                                                                        if($megyek[$i]=="Győr-Moson-Sopron megye")
                                                                        {
                                                                            $kiir.="#gyor,";
                                                                        }
                                                                        else
                                                                        {
                                                                            if($megyek[$i]=="Vas megye")
                                                                            {
                                                                                $kiir.="#vas,";
                                                                            }
                                                                            else
                                                                            {
                                                                                if($megyek[$i]=="Zala megye")
                                                                                {
                                                                                    $kiir.="#zala,";
                                                                                }
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }   
                            }
                        }
                    }    
                }
            }
        }
    }
}
echo "$kiir{
        pointer-events: all;
        fill: white;
    }"
?>