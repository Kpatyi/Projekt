<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="bootstrap-icons-1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="css/gombok formása.css">
    <link rel="stylesheet" href="css/formázások.css">
    <script src="bootstrap/js/bootstrap.min.js"></script>
    <script src="js/funkciók.js"></script>
    <title id="oldal">Fiók szerkesztése</title>
</head>
<?php
    session_start();
    $felhasznalonev=$_SESSION["felhasználónév"];
    $jelszo=$_SESSION["jelszó"];
    if($felhasznalonev==null)
    {
      header("Location:Bejelentkezés.html");
    }
    $adatbazis="adatok";
    $hostname="localhost";
    $adatbazis_felhasznalonev="root";
    $adatbazis_jelszo="";
    $kapcsolat= mysqli_connect($hostname,$adatbazis_felhasznalonev,$adatbazis_jelszo,$adatbazis);
    if(!$kapcsolat)
    {
        die("Sikertelen kapcsolódás: ".mysqli_connect_error());
    }
    $ellenorzes="SELECT * FROM fiókok WHERE felhasználónevek='$felhasznalonev' and jelszavak='$jelszo'";
    $eredmeny=$kapcsolat->query($ellenorzes);
    $sor=$eredmeny->fetch_assoc();
    $id=$sor["id"];
    echo 
        "
        <body onload='szamolas()'>
            <div class='d-flex vh-100'>
                <form action='Fiók frissítés.php' class='m-auto needs-validation' method='post' class='m-auto' id='kuldes' onsubmit='event.preventDefault();frissites()'>
                    <h1 id='r_b' class='mb-5 text-center'>Fiók szerkeztése</h1>
                    <div class='input-group mb-3'>
                        <i class='bi bi-at input-group-text'></i>
                        <div class='form-floating'>
                            <input type='email' class='form-control is-valid' id='email' name='email' value=".$sor["email"].">
                            <label for='email'>Email cím</label>
                            <div id='e_v' class='invalid-tooltip'>
                            </div>
                        </div>
                    </div>
                    <div class='input-group mb-3'>
                        <i class='bi bi-person-fill input-group-text'></i>
                        <div class='form-floating'>
                            <input type='text' class='form-control is-valid' id='felhasznalonev' value=".$sor["felhasználónevek"]." name='felhasználónév'>
                            <label for='felhasznalonev'>Felhasználónév</label>
                            <div id='f_v' class='invalid-tooltip'>
                            </div>
                        </div>
                    </div>
                    <div class='input-group mb-3'>
                        <i class='bi bi-lock-fill input-group-text'></i>
                        <div class='form-floating'>
                            <input type='password' class='form-control is-valid' value=".$sor["jelszavak"]." id='jelszo' name='jelszó'>
                            <label for='jelszo'>Jelszó</label>
                            <div id='j_v' class='invalid-tooltip'>
                            </div>
                        </div>
                        <i class='bi bi-eye-fill input-group-text' onclick='mutasd_j()' id='mutasd_j'></i>
                    </div>
                    <div class='input-group mb-3'>
                        <i class='bi bi-lock-fill input-group-text'></i>
                        <div class='form-floating'>
                            <input type='password' class='form-control is-valid' value=".$sor["jelszavak"]." id='jelszo_i' name='jelszó'>
                            <label for='jelszo_i'>Jelszó megerősítése</label>
                            <div id='j_i_v' class='invalid-tooltip'>
                            </div>
                        </div>
                        <i class='bi bi-eye-fill input-group-text' onclick='mutasd_j_i()' id='mutasd_j_i'></i>
                    </div>
                    <div class='input-group'>
                        <div class='form-floating'>
        ";
    $tortenetek_l="SELECT cím FROM történetek WHERE f_id='$id'";
    $tortenetek=$kapcsolat->query($tortenetek_l);
    $darab=$tortenetek->num_rows;
    if($darab>0)
    {
        echo 
        "
            <select class='form-select' id='t_cim' name='cím' required>
                <option value='0'>Válasz történetet</option>
        ";
        while($sor2=$tortenetek->fetch_assoc())
        {
            $tortenet=$sor2["cím"];
        echo
            "
            <option value='$tortenet'>$tortenet</option>";
        }
        echo
        "
        </select>
        <label for='t_cim' class='form-label'>Cím:</label>
        </div>
        <button type='button' class='btn btn-primary' onclick='tortenet_szerkesztes()'>
            Szerkesztés
        </button>
        <div class='invalid-tooltip'>
            Válasz történetet
        </div>
        ";
    }
    else
    {
        echo
        "
        <select class='form-select' id='t_cim' name='cím' disabled>
            <option value='0'>Még nincs történeted</option>
        </select>
        <label for='t_cim' class='form-label'>Cím:</label>
        </div>
        <button type='button' class='btn btn-primary disabled' onclick='tortenet_szerkesztes()'>
            Szerkesztés
        </button>
        <div class='invalid-tooltip'>
            Válasz történetet
        </div>
        ";
    }
                    echo
                    "
                    </div>
                    <div class='container mt-4 ms-3'>
                        <div class='row'>
                            <div class='col-4'>
                                <a href='Főoldal.php'>
                                    <button class='btn btn-primary me-5' type='button'>Vissza</button>
                                </a>
                            </div>
                            <div class='col-4'>
                                <a href='Főoldal.html'>
                                    <button class='btn btn-danger me-5' type='button' name='beküldés' onclick='torles()'>Törlés</button>
                                </a>
                            </div>
                            <div class='col-4'>
                                <button class='btn btn-success' type='submit' name='beküldés'>Mentés</button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </body>
        ";
?>