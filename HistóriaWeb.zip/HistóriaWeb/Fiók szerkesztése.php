<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/formázások.css">
    <script src="bootstrap/js/bootstrap.min.js"></script>
    <script src="js/funkciók.js"></script>
    <title>Fiók szerkesztése</title>
</head>
<?php
session_start();
$felhasznalonev=$_SESSION["felhasználónév"];
$jelszo=$_SESSION["jelszó"];

    $adatbazis="adatok";
    $hostname="localhost";
    $adatbazis_felhasznalonev="root";
    $adatbazis_jelszo="";
    $kapcsolat= mysqli_connect($hostname,$adatbazis_felhasznalonev,$adatbazis_jelszo,$adatbazis);
    if(!$kapcsolat)
    {
        die("Sikertelen kapcsolódás: ".mysqli_connect_error());
    }
    $ellenorzes="SELECT * FROM fiókok WHERE felhasználónevek='$felhasznalonev' and jelszavak='$jelszo'";
    $eredmeny=$kapcsolat->query($ellenorzes);
    while($sor=$eredmeny->fetch_assoc())
    {
        echo 
        "
        <h1 id='r_b'>Fiók szerkeztése</h1>
        <form action='Főoldal.php' method='post'>
            <table class='szerkeztes d-flex justify-content-center'>
                <tr>
                    <td>Email cím:</td>
                    <td><input id='email' type='email' value=".$sor["email"]."></td>
                </tr>
                <tr>
                    <td>Felhasználónév:</td>
                    <td><input name='felhasználónév' id='felhasznalonev' type='text' value=". $sor["felhasználónevek"]." required pattern='[A-Za-z0-9]{1,}'></td>
                </tr>
                <tr>
                    <td></td>
                    <td>
                    <div id='felhasznalonev_van'>Ez a felhasználónév már regisztrált</div>
                    </td>
                </tr>
                <tr>
                    <td>Jelszó:</td>
                    <td>
                        <input name='jelszó' id='jelszo' value=". $sor["jelszavak"]." required pattern='(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}' title='A jelszónak 8 karakter hosszúnak kell lennie és tartalmaznia kell kis betűt, nagy betűt és számot is' type='password'>
                    </td>
                </tr>
                <tr>
                    <td>
                        <button class='btn btn-primary gomb' type='button'><a href='Főoldal.php'>Vissza</a></button>
                    </td>
                    <td>
                        <button class='btn btn-primary' type='submit'><a>Mentés</a></button>
                    </td>
                </tr>
            </table>
        </form>
        ";
    }
?>