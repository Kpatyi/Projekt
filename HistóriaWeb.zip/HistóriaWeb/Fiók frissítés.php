<?php
    $adatbazis="adatok";
    $hostname="localhost";
    $adatbazis_felhasznalonev="root";
    $adatbazis_jelszo="";
    session_start();
    $felhasznalonev=$_SESSION["felhasználónév"];
    $jelszo=$_SESSION["jelszó"];
    if($felhasznalonev==null)
    {
      header("Location:Bejelentkezés.html");
    }
    $kapcsolat= mysqli_connect($hostname,$adatbazis_felhasznalonev,$adatbazis_jelszo,$adatbazis);
    if(!$kapcsolat)
    {
        die("Sikertelen kapcsolódás: ".mysqli_connect_error());
    }
    $uj_email=$_POST["email"];
    $uj_felhasznalonev=$_POST["felhasználónév"];
    $uj_jelszo=$_POST["jelszó"];
    $uj_jelszo_i=$_POST["jelszó_i"];
    $frissites="UPDATE fiókok SET felhasználónevek='$uj_felhasznalonev',jelszavak='$uj_jelszo',email='$uj_email' WHERE felhasználónevek='$felhasznalonev'";
    if($kapcsolat->query($frissites))
    {
        $_SESSION["felhasználónév"]=$uj_felhasznalonev;
        $_SESSION["jelszó"]=$uj_jelszo;
        header("Location: Főoldal.php");
    }
?>