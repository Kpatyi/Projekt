<?php
session_start();
$felhasznalonev=$_SESSION["felhasználónév"];
$uj_email=$_GET["újemail"];
$uj_felhasznalonev=$_GET["újfelhasználónév"];
$uj_jelszo=$_GET["újjelszó"];
    $adatbazis="adatok";
    $hostname="localhost";
    $adatbazis_felhasznalonev="root";
    $adatbazis_jelszo="";
    $kapcsolat= mysqli_connect($hostname,$adatbazis_felhasznalonev,$adatbazis_jelszo,$adatbazis);
    if(!$kapcsolat)
    {
        die("Sikertelen kapcsolódás: ".mysqli_connect_error());
    }
    $frissites="UPDATE fiókok SET felhasználónevek='$uj_felhasznalonev',jelszavak='$uj_jelszo',email='$uj_email' WHERE felhasználónevek='$felhasznalonev'";
    $kapcsolat->query($frissites);
    $_SESSION["felhasználónév"]=$uj_felhasznalonev;
    $_SESSION["jelszó"]=$uj_jelszo;
?>