<?php
$megye=$_POST["megye"];
$telepules=$_POST["település"];
$uj_cim=$_POST["cím"];
$uj_tortenet=$_POST["történet"];
session_start();
$felhasznalonev=$_SESSION["felhasználónév"];
$cim=$_SESSION["cím"];
$datum=$_POST["dátum"];
if($felhasznalonev==null)
{
  header("Location:Bejelentkezés.html");
}
$adatbazis="adatok";
$hostname="localhost";
$adatbazis_felhasznalonev="root";
$adatbazis_jelszo="";
$kapcsolat= mysqli_connect($hostname,$adatbazis_felhasznalonev,$adatbazis_jelszo,$adatbazis);
if(!$kapcsolat)
{
    die("Sikertelen kapcsolódás: ".mysqli_connect_error());
}
$id_l="SELECT id FROM fiókok WHERE felhasználónevek='$felhasznalonev'";
$id_e=$kapcsolat->query($id_l)->fetch_assoc();
$id=$id_e["id"];
$tortenet_l="SELECT történet_hely FROM történetek WHERE cím='$cim' AND f_id='$id'";
$tortenet=$kapcsolat->query($tortenet_l)->fetch_assoc();
$hely=$tortenet["történet_hely"];
$fajl=fopen("történetek/".$hely,"w") or die("Nem lehet a történetet frissíteni");
fwrite($fajl,$uj_tortenet);
fclose($fajl);
$frissites="UPDATE történetek SET történet_hely='$hely',megyék='$megye',települések='$telepules',dátum='$datum',cím='$uj_cim' WHERE cím='$cim' AND f_id='$id'";
$kapcsolat->query($frissites);
header("Location: Fiók szerkesztése.php");
?>