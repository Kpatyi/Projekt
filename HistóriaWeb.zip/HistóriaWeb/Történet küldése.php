<?php
    $adatbazis="adatok";
    $hostname="localhost";
    $adatbazis_felhasznalonev="root";
    $adatbazis_jelszo="";
    $kapcsolat= mysqli_connect($hostname,$adatbazis_felhasznalonev,$adatbazis_jelszo,$adatbazis);
    if(!$kapcsolat)
    {
        die("Sikertelen kapcsolodás: ".mysqli_connect_error());
    }
    session_start();
    $felhasznalonev=$_SESSION["felhasználónév"];
    $jelszo=$_SESSION["jelszó"];
    if($felhasznalonev==null)
    {
      header("Location:Bejelentkezés.html");
    }

    $megye=$_GET["megye"];
    $telepules=$_GET["település"];
    $tortenet=$_GET["történet"];
    $datum=$_GET["dátum"];
    $cim=$_GET["cím"];
    $id_l="SELECT id from fiókok WHERE felhasználónevek='$felhasznalonev' AND jelszavak='$jelszo'";
    $id_e=$kapcsolat->query($id_l);
    $id_egesz=$id_e->fetch_assoc();
    $id=$id_egesz["id"];
    $tortenetek="SELECT * FROM történetek WHERE f_id='$id'";
    $tortenetek_eredmeny=$kapcsolat->query($tortenetek);
    $id_t=1;
    $idik_l="SELECT id FROM történetek ORDER BY id";
    $idik=$kapcsolat->query($idik_l);
    while($sor=$idik->fetch_assoc())
    {
        if($sor["id"]==$id_t)
        {
            $id_t++;
        }
        else
        {
            break;
        }
    }
    $darab=$tortenetek_eredmeny->num_rows;
    $neve=$darab+1;
    if(!is_dir("történetek/".$id))
    {
        mkdir("történetek/".$id);
        $fajl=fopen("történetek/$id/$neve.txt","w") or die("Nem lehet a történetet beküldeni");
        fwrite($fajl,$tortenet);
        fclose($fajl);
        $kuldes="INSERT INTO történetek(id,cím,történet_hely,megyék,települések,dátum,f_id) VALUES('$id_t','$cim','$id/$neve.txt','$megye','$telepules','$datum','$id')";
        $kapcsolat->query($kuldes);
    }
    else
    {
        $fajl=fopen("történetek/$id/$neve.txt","w") or die("Nem lehet a történetet beküldeni");
        fwrite($fajl,$tortenet);
        fclose($fajl);
        $kuldes="INSERT INTO történetek(id,cím,történet_hely,megyék,települések,dátum,f_id) VALUES('$id_t','$cim','$id/$neve.txt','$megye','$telepules','$datum','$id')";
        $kapcsolat->query($kuldes);
    } 
?>