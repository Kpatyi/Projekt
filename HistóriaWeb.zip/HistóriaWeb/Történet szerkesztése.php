<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/gombok formása.css">
    <link rel="stylesheet" href="css/formázások.css">
    <script src="bootstrap/js/bootstrap.min.js"></script>
    <script src="js/funkciók.js"></script>
    <title>Történet írása</title>
</head>
<?php
session_start();
$felhasznalonev=$_SESSION["felhasználónév"];
$cim=$_GET["cím"];
$_SESSION["cím"]=$cim;
if($felhasznalonev==null)
{
  header("Location:Bejelentkezés.html");
}
$adatbazis="adatok";
$hostname="localhost";
$adatbazis_felhasznalonev="root";
$adatbazis_jelszo="";
$kapcsolat= mysqli_connect($hostname,$adatbazis_felhasznalonev,$adatbazis_jelszo,$adatbazis);
if(!$kapcsolat)
{
    die("Sikertelen kapcsolódás: ".mysqli_connect_error());
}
$id_l="SELECT id FROM fiókok WHERE felhasználónevek='$felhasznalonev'";
$id_e=$kapcsolat->query($id_l)->fetch_assoc();
$id=$id_e["id"];
$tortenet_l="SELECT történet_hely,megyék,települések FROM történetek WHERE cím='$cim' AND f_id='$id'";
$tortenet_e=$kapcsolat->query($tortenet_l)->fetch_assoc();
$megye=$tortenet_e["megyék"];
$telepules=$tortenet_e["települések"];
$fajl=fopen("történetek/".$tortenet_e["történet_hely"],"r");
$tortenet=fread($fajl,filesize("történetek/".$tortenet_e["történet_hely"]));
fclose($fajl);
echo
"
<body>
    <h1 id='r_b' class='text-center'>Történet szerkesztése</h1>
    <form action='Fiók szerkesztése.php' method='post' class='m-auto needs-validation w-75' id='kuldes' onsubmit='event.preventDefault();kuldes2();'>
        <div class='container'>
            <div class='row'>
                <div class='col-6'>
                    <div class='form-floating mb-5'>
                        <select class='form-select is-valid' name='megye' id='megye' onchange='feltolt()'>
                            <option value='0'>Válasz egy megyét...</option>
                            <option value='Bács-Kiskun'>Bács-Kiskun megye</option>
                            <option value='Baranya'>Baranya megye</option>
                            <option value='Békés'>Békés megye</option>
                            <option value='Borsod-Abaúj-Zemplén'>Borsod-Abaúj-Zemplén megye</option>
                            <option value='Csongrád-Csanád'>Csongrád-Csanád megye</option>
                            <option value='Fejér'>Fejér megye</option>
                            <option value='Győr-Moson-Sopron'>Győr-Moson-Sopron megye</option>
                            <option value='Hajdú-Bihar'>Hajdú-Bihar megye</option>
                            <option value='Heves'>Heves megye</option>
                            <option value='Jász-Nagykun-Szolnok'>Jász-Nagykun-Szolnok megye</option>
                            <option value='Komárom-Esztergom'>Komárom-Esztergom megye</option>
                            <option value='Nógrád'>Nógrád megye</option>
                            <option value='Pest'>Pest megye</option>
                            <option value='Somogy'>Somogy megye</option>
                            <option value='Szabolcs-Szatmár-Bereg'>Szabolcs-Szatmár-Bereg megye</option>
                            <option value='Tolna' >Tolna megye</option>
                            <option value='Vas'>Vas megye</option>
                            <option value='Veszprém'>Veszprém megye</option>
                            <option value='Zala'>Zala megye</option>
                        </select>
                        <label for='megye' class='form-label'>Megye:</label>
                        <div class='invalid-tooltip' id='m_v'>
                            Válasz megyét
                        </div>
                    </div>
                </div>
                <div class='col-6'>
                    <div class='form-floating'>
                        <select class='form-select is-valid' id='telepules' name='település'>
                            <option value='0'>Válasz egy települést...</option>
                        </select>
                        <label for='telepules' class='form-label'>Település:</label>
                        <div class='invalid-tooltip' id='t_v'>
                            Válasz települést
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class='form-floating'>
            <input type='text' value='$cim' class='form-control is-valid' name='cim' id='t_cim'>
            <label class='form-label' for='t_cim'>Cím</label>
            <div class='invalid-tooltip' id='c_v'>
                Hibás cím
            </div>
        </div>
        <div class='form-floating mb-5'>
            <textarea class='form-control is-valid' id='tortenet' name='történet' style='height: 350px;' placeholder='Történet'>$tortenet</textarea>
            <label for='tortenet'>Történet</label>
            <div class='invalid-tooltip' id='to_v'>
                Hibás történet
            </div>
        </div>
        <div class='container'>
            <div class='row'>
                <div class='col-4 d-flex justify-content-start'>
                    <a href='Fiók szerkesztése.php'>
                        <button class='btn btn-primary' type='button'>Vissza</button>
                    </a>
                </div>
                <div class='col-4 d-flex justify-content-center'>
                    <button class='btn btn-danger me-2' type='button' onclick='torles2()'>Törlés</button>
                </div>
                <div class='col-4 d-flex justify-content-end'>
                    <button class='btn btn-success' type='submit'>Mentés</button>
                </div>
            </div>
        </div>
    </form>
</body>
";
?>
<script>
    <?php echo"
    let megye1='$megye';
    let telepules1='$telepules'"?>;
    let megyek=document.querySelectorAll("#megye option");
    for(let i=1;i<megyek.length;i++)
    {
        if(megyek[i].value==megye1)
        {
            megyek[i].selected="true";
            feltolt();
            setTimeout(telepulesek,20)
        }
    }
    function telepulesek()
    {
        let telepulesek=document.querySelectorAll("#telepules option");
            for(let j=1;j<telepulesek.length;j++)
            {
                if(telepules1==telepulesek[j].value)
                {
                    telepulesek[j].selected="true";
                }
            }   
    }
</script>