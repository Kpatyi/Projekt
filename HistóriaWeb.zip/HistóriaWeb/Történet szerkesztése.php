<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/gombok formása.css">
    <link rel="stylesheet" href="css/formázások.css">
    <link rel="icon" type="image/x-icon" href="Képek/Logo.png">
    <script src="bootstrap/js/bootstrap.min.js"></script>
    <script src="bootstrap/js/bootstrap.bundle.js"></script>
    <script src="js/funkciók.js"></script>
    <title id="oldal">Történet szerkesztése</title>
</head>
<?php
$adatbazis="adatok";
$hostname="localhost";
$adatbazis_felhasznalonev="root";
$adatbazis_jelszo="";
$kapcsolat= mysqli_connect($hostname,$adatbazis_felhasznalonev,$adatbazis_jelszo,$adatbazis);
if(!$kapcsolat)
{
    die("Sikertelen kapcsolódás: ".mysqli_connect_error());
}
$megye_f="is-valid";
$telepules_f="is-valid";
$cim_f="is-valid";
$cim_v="";
$tortenet_f="";
$tortenet_v="";
if($_SERVER["REQUEST_METHOD"]=="POST")
{
    session_start();
    $felhasznalonev=$_SESSION["felhasználónév"];
    $cim=$_SESSION["cím"];
    $uj_cim=$_POST["cím"];
    $megye=$_POST["megye"];
    $telepules=$_POST["település"];
    $uj_tortenet=$_POST["történet"];
    $van_m=false;
    $van_t=false;
    if(empty($uj_cim))
    {
        $cim_f="is-invalid";
        $cim_v="Kötelező címet adni!";
    }
    else
    {
        if(!preg_match("/[a-zA-Z-0-9]/",$uj_cim))
        {
            $cim_f="is-invalid";
            $cim_v="A cím nem valódi!";  
        }
        else
        {
            if($uj_cim!=$cim)
            {
                $id_l="SELECT id FROM fiókok WHERE felhasználónevek='$felhasznalonev'";
                $id_e=$kapcsolat->query($id_l)->fetch_assoc();
                $id=$id_e["id"];
                $ellenorzes="SELECT * FROM történetek WHERE f_id='$id' AND cím='$uj_cim'";
                $van_e=$kapcsolat->query($ellenorzes)->num_rows;
                if($van_e>0)
                {
                    $cim_f="is-invalid";
                    $cim_v="Ez a cím már létezik!";
                }
                else
                {
                    $cim_f="is-valid";
                    $cim_v="";
                }
            }
            else
            {
                $cim_f="is-valid";
                $cim_v="";
            }
        }
    }

    if(empty($megye))
    {
        $megye_f="is-invalid";
    }
    else
    {
        $megyek=array("Bács-Kiskun megye","Baranya megye","Békés megye","Borsod-Abaúj-Zemplén megye","Csongrád-Csanád megye","Fejér megye","Győr-Moson-Sopron megye","Hajdú-Bihar megye","Heves megye","Jász-Nagykun-Szolnok megye","Komárom-Esztergom megye","Nógrád megye","Pest megye","Somogy megye","Szabolcs-Szatmár-Bereg megye","Tolna megye","Vas megye","Veszprém megye","Zala megye");
        for($i=0;$i<count($megyek);$i++)
        {
            if(trim($megye)==$megyek[$i])
            {
                $van_m=true;
            }
        }
        if($van_m)
        {
            $megye_f="is-valid";
        }
        else
        {
            $megye_f="is-invalid";
        }
    }

    if(empty($telepules))
    {
        $telepules_f="is-invalid";
    }
    else
    {
        if($van_m)
        {
            $fajl=fopen("települések/".trim($megye).".txt","r");
            $telepulesek=explode("\n",fread($fajl,filesize("települések/".trim($megye).".txt")));
            for($i=0;$i<count($telepulesek);$i++)
            {
                if($telepules==trim($telepulesek[$i]))
                {
                    $van_t=true;
                }
            }
            if($van_t)
            {
                $telepules_f="is-valid";
            }
            else
            {
                $telepules_f="is-invalid"; 
            }

        }
        else
        {
            $telepules_f="is-invalid";
        }
    }
    if(empty($uj_tortenet))
    {
        $tortenet_f="is-invalid";
        $tortenet_v="Kötelező szöveget írni!";   
    }
    else
    {
        if(!preg_match("/[a-zA-Z-0-9]/",$uj_tortenet))
        {
            $tortenet_f="is-invalid";
            $tortenet_v="A történet nem tartalmaz betűket!";   
        }
        else
        {
            $tortenet_f="is-valid";
            $tortenet_v="";
        }

    }
    if($cim_v=="" && $tortenet_v=="" && $megye_f=="is-valid" && $telepules_f=="is-valid")
    {
        $id_l="SELECT id FROM fiókok WHERE felhasználónevek='$felhasznalonev'";
        $id_e=$kapcsolat->query($id_l)->fetch_assoc();
        $id=$id_e["id"];
        $datum=date("Y.m.d H:i:s");
        $tortenet_l="SELECT történet_hely FROM történetek WHERE cím='$cim' AND f_id='$id'";
        $tortenet=$kapcsolat->query($tortenet_l)->fetch_assoc();
        $hely=$tortenet["történet_hely"];
        $fajl=fopen("történetek/".$hely,"w") or die("Nem lehet a történetet frissíteni");
        fwrite($fajl,$uj_tortenet);
        fclose($fajl);
        $frissites="UPDATE történetek SET történet_hely='$hely',megyék='$megye',települések='$telepules',dátum='$datum',cím='$uj_cim' WHERE cím='$cim' AND f_id='$id'";
        $kapcsolat->query($frissites);
        header("Location: Fiók szerkesztése.php");
    }
}
else
{
    session_start();
    $uj_cim=$_GET["cím"];
    $_SESSION["cím"]=$uj_cim;
    $felhasznalonev=$_SESSION["felhasználónév"];
    $id_l="SELECT id FROM fiókok WHERE felhasználónevek='$felhasznalonev'";
    $id_e=$kapcsolat->query($id_l)->fetch_assoc();
    $id=$id_e["id"];
    $tortenet_l="SELECT történet_hely,megyék,települések,cím FROM történetek WHERE cím='$uj_cim' AND f_id='$id'";
    $tortenet_e=$kapcsolat->query($tortenet_l)->fetch_assoc();
    $uj_cim=$tortenet_e["cím"];
    $megye=$tortenet_e["megyék"];
    $telepules=$tortenet_e["települések"];
    $fajl=fopen("történetek/".$tortenet_e["történet_hely"],"r");
    $uj_tortenet=fread($fajl,filesize("történetek/".$tortenet_e["történet_hely"]));
    fclose($fajl);
}
echo
"
<body onload='szamolas();kijelentkezes()'>
<h1 id='r_b' class='text-center'>Történet írása</h1>
<form novalidate action='".htmlspecialchars($_SERVER["PHP_SELF"])."' method='post' class='m-auto needs-validation w-75' id='kuldes'>
    <div class='container-fluid'>
        <div class='row mb-5'>
            <div class='col-6'>
                <div class='dropdown form-floating'>
                    <input autocomplete='off' class='form-select dropdown-toggle $megye_f' id='megye' value='$megye' name='megye' type='text' data-bs-toggle='dropdown' onkeyup='kereses_m()'>
                    <ul class='dropdown-menu megyek w-100' aria-labelledby='megye' id='lehetosegek1'>
                        <li onclick='"."valasztot_m(".'"'."Bács-Kiskun megye".'"'.")'"." class='dropdown-item'>Bács-Kiskun megye</li>
                        <li onclick='"."valasztot_m(".'"'."Baranya megye".'"'.")'"." class='dropdown-item'>Baranya megye</li>
                        <li onclick='"."valasztot_m(".'"'."Békés megye".'"'.")'"." class='dropdown-item'>Békés megye</li>
                        <li onclick='"."valasztot_m(".'"'."Borsod-Abaúj-Zemplén megye".'"'.")'"." class='dropdown-item'>Borsod-Abaúj-Zemplén megye</li>
                        <li onclick='"."valasztot_m(".'"'."Csongrád-Csanád megye".'"'.")'"." class='dropdown-item'>Csongrád-Csanád megye</li>
                        <li onclick='"."valasztot_m(".'"'."Fejér megye".'"'.")'"." class='dropdown-item'>Fejér megye</li>
                        <li onclick='"."valasztot_m(".'"'."Győr-Moson-Sopron megye".'"'.")'"." class='dropdown-item'>Győr-Moson-Sopron megye</li>
                        <li onclick='"."valasztot_m(".'"'."Hajdú-Bihar megye".'"'.")'"." class='dropdown-item'>Hajdú-Bihar megye</li>
                        <li onclick='"."valasztot_m(".'"'."Heves megye".'"'.")'"." class='dropdown-item'>Heves megye</li>
                        <li onclick='"."valasztot_m(".'"'."Jász-Nagykun-Szolnok megye".'"'.")'"." class='dropdown-item'>Jász-Nagykun-Szolnok megye</li>
                        <li onclick='"."valasztot_m(".'"'."Komárom-Esztergom megye".'"'.")'"." class='dropdown-item'>Komárom-Esztergom megye</li>
                        <li onclick='"."valasztot_m(".'"'."Nógrád megye".'"'.")'"." class='dropdown-item'>Nógrád megye</li>
                        <li onclick='"."valasztot_m(".'"'."Pest megye".'"'.")'"." class='dropdown-item'>Pest megye</li>
                        <li onclick='"."valasztot_m(".'"'."Somogy megye".'"'.")'"." class='dropdown-item'>Somogy megye</li>
                        <li onclick='"."valasztot_m(".'"'."Szabolcs-Szatmár-Bereg megye".'"'.")'"." class='dropdown-item'>Szabolcs-Szatmár-Bereg megye</li>
                        <li onclick='"."valasztot_m(".'"'."Tolna megye".'"'.")'"." class='dropdown-item'>Tolna megye</li>
                        <li onclick='"."valasztot_m(".'"'."Vas megye".'"'.")'"." class='dropdown-item'>Vas megye</li>
                        <li onclick='"."valasztot_m(".'"'."Veszprém megye".'"'.")'"." class='dropdown-item'>Veszprém megye</li>
                        <li onclick='"."valasztot_m(".'"'."Zala megye".'"'.")'"." class='dropdown-item'>Zala megye</li>
                    </ul>
                    <label for='megye' class='form-label'>Válasz egy megyét:</label>
                    <div class='invalid-tooltip'>
                        Válasz megyét
                    </div>
                </div>
            </div>
            <div class='col-6'>
                <div class='dropdown form-floating'>
                    <input autocomplete='off' onclick='feltolt_t()' class='form-select dropdown-toggle $telepules_f' id='telepules' value='$telepules' name='település' type='text' data-bs-toggle='dropdown' onkeyup='kereses_t()'>
                    <ul class='dropdown-menu w-100 telepulesek' aria-labelledby='telepules' id='lehetosegek2'>
                    </ul>
                    <label for='telepules' class='form-label'>Válasz egy települést:</label>
                    <div class='invalid-tooltip'>
                        Válasz települést
                    </div>
                </div>
            </div>
        </div>
    </div>
        <div class='form-floating'>
            <input type='text' value='$uj_cim' class='form-control $cim_f' name='cím' id='t_cim'>
            <label class='form-label' for='t_cim'>Cím</label>
            <div class='invalid-tooltip'>
                $cim_v
            </div>
        </div>
        <div class='form-floating mb-3'>
            <textarea class='form-control $tortenet_f' id='tortenet' name='történet' style='height: 350px;' placeholder='Történet'>$uj_tortenet</textarea>
            <label for='tortenet'>Történet</label>
            <div class='invalid-tooltip'>
                $tortenet_v
            </div>
        </div>
        <div class='container'>
            <div class='row'>
                <div class='col-4 d-flex justify-content-start'>
                    <a href='Fiók szerkesztése.php'>
                        <button class='btn btn-primary' type='button'>Vissza</button>
                    </a>
                </div>
                <div class='col-4 d-flex justify-content-center'>
                    <button class='btn btn-danger me-2' type='button' onclick='torles2()'>Törlés</button>
                </div>
                <div class='col-4 d-flex justify-content-end'>
                    <button class='btn btn-success' type='submit'>Mentés</button>
                </div>
            </div>
        </div>
    </form>
</body>
";
?>