<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/formázások.css">
    <script src="bootstrap/js/bootstrap.min.js"></script>
    <script src="js/funkciók.js"></script>
    <title id="oldal">Főoldal</title>
</head>
<body onscroll="parallax()" onload="szamolas();kijelentkezes()">
</body>
<?php
  session_start();
  $felhasznalonev=$_SESSION["felhasználónév"];
  if($felhasznalonev==null)
  {
    header("Location:Bejelentkezés.html");
  }
  else
  {
    echo
        "
        <nav class='navbar navbar-expand-md navbar-dark'>
          <div class='container-fluid'>
            <a class='navbar-brand' href='Főoldal.php'>
            <img src='Képek/Logo.png' width='100px'>
            </a>
            <button class='navbar-toggler' type='button' data-bs-toggle='collapse' data-bs-target='#navbar'>
              <span class='navbar-toggler-icon'></span>
            </button>
            <div class='collapse navbar-collapse justify-content-start' id='navbar'>
              <ul class='navbar-nav'>
                <li class='nav-item'>
                  <a class='nav-link me-5 text-light' href='Képek.php'>Képek</a>
                </li>
                <li class='nav-item'>
                  <a class='nav-link me-5 text-light' href='Videók.php'>Videók</a>
                </li>
                <li class='nav-item'>
                  <a class='nav-link me-5 text-light' href='Térkép.php'>Térkép</a>
                </li>     
              </ul>
            </div>
            <div class='collapse navbar-collapse justify-content-end' id='navbar'>
              <ul class='navbar-nav'>
                <li class='nav-item dropdown'>
                  <a class='nav-link text-light dropdown-toggle' href='#' role='button' data-bs-toggle='dropdown'>$felhasznalonev</a>
                  <ul class='dropdown-menu dropdown-menu-end'>
                    <li><a class='dropdown-item' href='Fiók szerkesztése.php'>Fiók szerkesztése</a></li>
                    <li><a class='dropdown-item'href='Történet írása.php''>Történet írása</a></li>
                    <li><a class='dropdown-item' href='Kijelentkezés.php'>Kijelentkezés</a></li>
                  </ul>
                </li>
              </ul>
            </div>
          </div>
        </nav>
        <div class='d-flex justify-content-center align-items-center position-relative vh-100'>
          <h1 id='cim' class='text-center position-absolute text-light'>HistóriaWeb</h1>
          <img src='Képek/Bal_also.png' class='position-absolute w-100' id='ba'>
          <img src='Képek/Jobb_also.png' class='position-absolute w-100' id='ja'> 
          <img src='Képek/Bal_felso.png' class='position-absolute w-100' id='bf'>
          <img src='Képek/Jobb_felso.png' class='position-absolute w-100' id='jf'>
        </div>
        <div class='tartalom position-relative w-100 text-light ps-4 pe-4 mb-5 pt-5'>
          <h2>Célunk</h2>
          <br>
          <p>
            Egy olyan interaktív weboldal megalkotása ami megőrzi a régi már feledésbe merülő települések történeteit. Felkeresünk olyan helyeket,
             embereket aminek/akiknek van mondanivalójuk az utókor számára vagy csak egyszerűen van egy érdekes történetük.
          </p>
        </div>
        <footer>
          <h2>Elérhetőségek:</h2>
          <ul class='list-unstyled ms-3'>
            <li>email cím</li>
          </ul>
        </footer>

        ";
  }
?>