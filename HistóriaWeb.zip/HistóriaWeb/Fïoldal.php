<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/formázások.css">
    <script src="bootstrap/js/bootstrap.min.js"></script>
    <script src="js/funkciók.js"></script>
    <title>Főoldal</title>
</head>
<body onscroll="parallax()">
</body>
<?php
  session_start();
  $felhasznalonev=$_SESSION["felhasználónév"];
  if($felhasznalonev==null)
  {
    header("Location:Bejelentkezés.html");
  }
  else
  {
    echo
        "
        <nav class='navbar navbar-expand-md navbar-dark'>
          <div class='container-fluid'>
            <a class='navbar-brand' href='Főoldal.php'>
            <img src='Képek/Logo.png' width='100px'>
            </a>
            <button class='navbar-toggler' type='button' data-bs-toggle='collapse' data-bs-target='#navbar'>
              <span class='navbar-toggler-icon'></span>
            </button>
            <div class='collapse navbar-collapse justify-content-start' id='navbar'>
              <ul class='navbar-nav'>
                <li class='nav-item'>
                  <a class='nav-link' href='Képek.php'>Képek</a>
                </li>
                <li class='nav-item'>
                  <a class='nav-link' href='Videók.php'>Videók</a>
                </li>
                <li class='nav-item'>
                  <a class='nav-link' href='Térkép.php'>Térkép</a>
                </li>     
              </ul>
            </div>
            <div class='collapse navbar-collapse justify-content-end' id='navbar'>
              <ul class='navbar-nav'>
                <li class='nav-item dropdown'>
                  <a class='nav-link dropdown-toggle' href='#' role='button' data-bs-toggle='dropdown'>$felhasznalonev</a>
                  <ul class='dropdown-menu dropdown-menu-end'>
                    <li><a class='dropdown-item' href='Fiók szerkesztése.php'>Fiók szerkesztése</a></li>
                    <li><a class='dropdown-item'href='Történet írása.php''>Történet írása</a></li>
                    <li><a class='dropdown-item' href='Kijelentkezés.php'>Kijelentkezés</a></li>
                  </ul>
                </li>
              </ul>
            </div>
          </div>
        </nav>
        <div class='d-flex justify-content-center align-items-center parallax vh-100'>
          <h1 id='cim'>HistóriaWeb</h1>
          <img src='Képek/Bal_also.png' id='ba'>
          <img src='Képek/Jobb_also.png' id='ja'> 
          <img src='Képek/Bal_felso.png' id='bf'>
          <img src='Képek/Jobb_felso.png' id='jf'>
        </div>
        <div class='tartalom'>
          <h2>Cím</h2>
          <br>
          <p>A videó kiváló segítséget nyújt a hatékony kommunikációban. Az Online videó lehetőségre kattintva beillesztheti a hozzáadni kívánt videó beágyazási kódját. Kulcsszavas keresést is végezhet annak érdekében, hogy megtalálja a dokumentumához leginkább illő videót.
            Annak érdekében, hogy dokumentuma még professzionálisabb hatást keltsen, a Word egymáshoz illő élőfej-, élőláb-, fedőlap- és szövegdobozdizájnokat kínál. Hozzáadhat például egy egymáshoz illő fedőlapot, élőfejet és oldalsávot. Kattintson a Beillesztés parancsra, és válassza ki a kívánt elemeket a különféle galériákból.
            A témák és stílusok ugyancsak segíthetnek abban, hogy dokumentuma összeszedettebb legyen. Amikor a Tervezés fülre kattint, és egy új témát választ, a program a képeket, a diagramokat és a SmartArt-ábrákat is az új témához igazítja. A stílusok alkalmazásakor a címsorokat az új témához igazítja a program.
            Takarítson meg időt a Word új gombjaival, melyek ott jelennek meg, ahol épp szükség van rájuk. Ha módosítani szeretné, hogy hogyan illeszkedjenek a képek a dokumentumba, kattintson a képre, és megjelennek mellette az elrendezési lehetőségek. Amikor táblázattal dolgozik, kattintson oda, ahova sort vagy oszlopot szeretne beszúrni, majd kattintson a pluszjelre.
            Az olvasás is egyszerűbb az új olvasási elrendezésnek köszönhetően. Összecsukhatja a dokumentum egyes részeit, hogy a kívánt szövegre összpontosíthasson. Ha félbe kell szakítania az olvasást, a Word megjegyzi, hogy hol hagyta abba – még akkor is, ha másik eszközön történik.
          </p>
          <p>A videó kiváló segítséget nyújt a hatékony kommunikációban. Az Online videó lehetőségre kattintva beillesztheti a hozzáadni kívánt videó beágyazási kódját. Kulcsszavas keresést is végezhet annak érdekében, hogy megtalálja a dokumentumához leginkább illő videót.
            Annak érdekében, hogy dokumentuma még professzionálisabb hatást keltsen, a Word egymáshoz illő élőfej-, élőláb-, fedőlap- és szövegdobozdizájnokat kínál. Hozzáadhat például egy egymáshoz illő fedőlapot, élőfejet és oldalsávot. Kattintson a Beillesztés parancsra, és válassza ki a kívánt elemeket a különféle galériákból.
            A témák és stílusok ugyancsak segíthetnek abban, hogy dokumentuma összeszedettebb legyen. Amikor a Tervezés fülre kattint, és egy új témát választ, a program a képeket, a diagramokat és a SmartArt-ábrákat is az új témához igazítja. A stílusok alkalmazásakor a címsorokat az új témához igazítja a program.
            Takarítson meg időt a Word új gombjaival, melyek ott jelennek meg, ahol épp szükség van rájuk. Ha módosítani szeretné, hogy hogyan illeszkedjenek a képek a dokumentumba, kattintson a képre, és megjelennek mellette az elrendezési lehetőségek. Amikor táblázattal dolgozik, kattintson oda, ahova sort vagy oszlopot szeretne beszúrni, majd kattintson a pluszjelre.
            Az olvasás is egyszerűbb az új olvasási elrendezésnek köszönhetően. Összecsukhatja a dokumentum egyes részeit, hogy a kívánt szövegre összpontosíthasson. Ha félbe kell szakítania az olvasást, a Word megjegyzi, hogy hol hagyta abba – még akkor is, ha másik eszközön történik.
          </p>
          <p>A videó kiváló segítséget nyújt a hatékony kommunikációban. Az Online videó lehetőségre kattintva beillesztheti a hozzáadni kívánt videó beágyazási kódját. Kulcsszavas keresést is végezhet annak érdekében, hogy megtalálja a dokumentumához leginkább illő videót.
            Annak érdekében, hogy dokumentuma még professzionálisabb hatást keltsen, a Word egymáshoz illő élőfej-, élőláb-, fedőlap- és szövegdobozdizájnokat kínál. Hozzáadhat például egy egymáshoz illő fedőlapot, élőfejet és oldalsávot. Kattintson a Beillesztés parancsra, és válassza ki a kívánt elemeket a különféle galériákból.
            A témák és stílusok ugyancsak segíthetnek abban, hogy dokumentuma összeszedettebb legyen. Amikor a Tervezés fülre kattint, és egy új témát választ, a program a képeket, a diagramokat és a SmartArt-ábrákat is az új témához igazítja. A stílusok alkalmazásakor a címsorokat az új témához igazítja a program.
            Takarítson meg időt a Word új gombjaival, melyek ott jelennek meg, ahol épp szükség van rájuk. Ha módosítani szeretné, hogy hogyan illeszkedjenek a képek a dokumentumba, kattintson a képre, és megjelennek mellette az elrendezési lehetőségek. Amikor táblázattal dolgozik, kattintson oda, ahova sort vagy oszlopot szeretne beszúrni, majd kattintson a pluszjelre.
            Az olvasás is egyszerűbb az új olvasási elrendezésnek köszönhetően. Összecsukhatja a dokumentum egyes részeit, hogy a kívánt szövegre összpontosíthasson. Ha félbe kell szakítania az olvasást, a Word megjegyzi, hogy hol hagyta abba – még akkor is, ha másik eszközön történik.
          </p>
        </div>
        <div class='tartalom'>
          <h2>Cím</h2>
          <br>
          <p>A videó kiváló segítséget nyújt a hatékony kommunikációban. Az Online videó lehetőségre kattintva beillesztheti a hozzáadni kívánt videó beágyazási kódját. Kulcsszavas keresést is végezhet annak érdekében, hogy megtalálja a dokumentumához leginkább illő videót.
          Annak érdekében, hogy dokumentuma még professzionálisabb hatást keltsen, a Word egymáshoz illő élőfej-, élőláb-, fedőlap- és szövegdobozdizájnokat kínál. Hozzáadhat például egy egymáshoz illő fedőlapot, élőfejet és oldalsávot. Kattintson a Beillesztés parancsra, és válassza ki a kívánt elemeket a különféle galériákból.
          A témák és stílusok ugyancsak segíthetnek abban, hogy dokumentuma összeszedettebb legyen. Amikor a Tervezés fülre kattint, és egy új témát választ, a program a képeket, a diagramokat és a SmartArt-ábrákat is az új témához igazítja. A stílusok alkalmazásakor a címsorokat az új témához igazítja a program.
          Takarítson meg időt a Word új gombjaival, melyek ott jelennek meg, ahol épp szükség van rájuk. Ha módosítani szeretné, hogy hogyan illeszkedjenek a képek a dokumentumba, kattintson a képre, és megjelennek mellette az elrendezési lehetőségek. Amikor táblázattal dolgozik, kattintson oda, ahova sort vagy oszlopot szeretne beszúrni, majd kattintson a pluszjelre.
          Az olvasás is egyszerűbb az új olvasási elrendezésnek köszönhetően. Összecsukhatja a dokumentum egyes részeit, hogy a kívánt szövegre összpontosíthasson. Ha félbe kell szakítania az olvasást, a Word megjegyzi, hogy hol hagyta abba – még akkor is, ha másik eszközön történik.
          </p>
          <p>A videó kiváló segítséget nyújt a hatékony kommunikációban. Az Online videó lehetőségre kattintva beillesztheti a hozzáadni kívánt videó beágyazási kódját. Kulcsszavas keresést is végezhet annak érdekében, hogy megtalálja a dokumentumához leginkább illő videót.
          Annak érdekében, hogy dokumentuma még professzionálisabb hatást keltsen, a Word egymáshoz illő élőfej-, élőláb-, fedőlap- és szövegdobozdizájnokat kínál. Hozzáadhat például egy egymáshoz illő fedőlapot, élőfejet és oldalsávot. Kattintson a Beillesztés parancsra, és válassza ki a kívánt elemeket a különféle galériákból.
          A témák és stílusok ugyancsak segíthetnek abban, hogy dokumentuma összeszedettebb legyen. Amikor a Tervezés fülre kattint, és egy új témát választ, a program a képeket, a diagramokat és a SmartArt-ábrákat is az új témához igazítja. A stílusok alkalmazásakor a címsorokat az új témához igazítja a program.
          Takarítson meg időt a Word új gombjaival, melyek ott jelennek meg, ahol épp szükség van rájuk. Ha módosítani szeretné, hogy hogyan illeszkedjenek a képek a dokumentumba, kattintson a képre, és megjelennek mellette az elrendezési lehetőségek. Amikor táblázattal dolgozik, kattintson oda, ahova sort vagy oszlopot szeretne beszúrni, majd kattintson a pluszjelre.
          Az olvasás is egyszerűbb az új olvasási elrendezésnek köszönhetően. Összecsukhatja a dokumentum egyes részeit, hogy a kívánt szövegre összpontosíthasson. Ha félbe kell szakítania az olvasást, a Word megjegyzi, hogy hol hagyta abba – még akkor is, ha másik eszközön történik.
          </p>
          <p>A videó kiváló segítséget nyújt a hatékony kommunikációban. Az Online videó lehetőségre kattintva beillesztheti a hozzáadni kívánt videó beágyazási kódját. Kulcsszavas keresést is végezhet annak érdekében, hogy megtalálja a dokumentumához leginkább illő videót.
          Annak érdekében, hogy dokumentuma még professzionálisabb hatást keltsen, a Word egymáshoz illő élőfej-, élőláb-, fedőlap- és szövegdobozdizájnokat kínál. Hozzáadhat például egy egymáshoz illő fedőlapot, élőfejet és oldalsávot. Kattintson a Beillesztés parancsra, és válassza ki a kívánt elemeket a különféle galériákból.
          A témák és stílusok ugyancsak segíthetnek abban, hogy dokumentuma összeszedettebb legyen. Amikor a Tervezés fülre kattint, és egy új témát választ, a program a képeket, a diagramokat és a SmartArt-ábrákat is az új témához igazítja. A stílusok alkalmazásakor a címsorokat az új témához igazítja a program.
          Takarítson meg időt a Word új gombjaival, melyek ott jelennek meg, ahol épp szükség van rájuk. Ha módosítani szeretné, hogy hogyan illeszkedjenek a képek a dokumentumba, kattintson a képre, és megjelennek mellette az elrendezési lehetőségek. Amikor táblázattal dolgozik, kattintson oda, ahova sort vagy oszlopot szeretne beszúrni, majd kattintson a pluszjelre.
          Az olvasás is egyszerűbb az új olvasási elrendezésnek köszönhetően. Összecsukhatja a dokumentum egyes részeit, hogy a kívánt szövegre összpontosíthasson. Ha félbe kell szakítania az olvasást, a Word megjegyzi, hogy hol hagyta abba – még akkor is, ha másik eszközön történik.
          </p>
        </div>
        ";
  }
?>