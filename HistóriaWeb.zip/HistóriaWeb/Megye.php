<?php
session_start();
$_SESSION["megye"]=$_GET["megye"];
header("Location:Történetek.php");
?>