<?php
    session_start();
    $felhasznalonev=$_SESSION["felhasználónév"];
    $jelszo=$_SESSION["jelszó"];
    if($felhasznalonev==null)
    {
      header("Location:Bejelentkezés.php");
    }
    $adatbazis="adatok";
    $hostname="localhost";
    $adatbazis_felhasznalonev="root";
    $adatbazis_jelszo="";
    $kapcsolat= mysqli_connect($hostname,$adatbazis_felhasznalonev,$adatbazis_jelszo,$adatbazis);
    if(!$kapcsolat)
    {
        die("Sikertelen kapcsolódás: ".mysqli_connect_error());
    }
    $fajlok="SELECT történet_hely FROM történetek,fiókok WHERE felhasználónevek='$felhasznalonev' AND történetek.f_id=fiókok.id";
    $mappa="SELECT id FROM fiókok WHERE felhasználónevek='$felhasznalonev'";
    $eredmeny1=$kapcsolat->query($fajlok);
    if($eredmeny1->num_rows>0)
    {
        while($sor=$eredmeny1->fetch_assoc())
        {
            unlink("történetek/".$sor["történet_hely"]);
        }
        $eredmeny2=$kapcsolat->query($mappa);
        $sorok=$eredmeny2->fetch_assoc();
        rmdir("történetek/".$sorok["id"]);
        $torles_t="DELETE FROM történetek WHERE f_id IN(SELECT id FROM fiókok WHERE felhasználónevek='$felhasznalonev')";
        $kapcsolat->query($torles_t);
    }
    $torles_f="DELETE FROM fiókok WHERE felhasználónevek='$felhasznalonev'";
    $kapcsolat->query($torles_f);
    session_destroy();
    header("Location: Főoldal.html");
?>